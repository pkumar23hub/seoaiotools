"""
config.py — Central configuration for Scout.
Reads API keys from .env file. All other modules import from here.
Never hardcode keys elsewhere.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# ── Locate .env (either in scout/ or one level up) ──────────────────────────
_BASE = Path(__file__).parent
_ENV_PATH = _BASE / ".env"
if not _ENV_PATH.exists():
    _ENV_PATH = _BASE.parent / ".env"
load_dotenv(dotenv_path=_ENV_PATH)


# ── API Keys ─────────────────────────────────────────────────────────────────
SERPAPI_KEY        = os.getenv("SERPAPI_KEY", "")
OPR_KEY            = os.getenv("OPR_KEY", "")          # Open PageRank
REDDIT_CLIENT_ID   = os.getenv("REDDIT_CLIENT_ID", "")
REDDIT_CLIENT_SECRET = os.getenv("REDDIT_CLIENT_SECRET", "")
REDDIT_USER_AGENT  = os.getenv("REDDIT_USER_AGENT", "scout:v1.0 (by /u/user)")
GITHUB_TOKEN       = os.getenv("GITHUB_TOKEN", "")


# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR     = _BASE
DB_DIR       = BASE_DIR / "databases"
EXPORT_DIR   = BASE_DIR / "exports"
LOG_DIR      = BASE_DIR / "logs"

for _d in (DB_DIR, EXPORT_DIR, LOG_DIR):
    _d.mkdir(parents=True, exist_ok=True)


# ── Rate Limits (seconds between requests) ───────────────────────────────────
RATE_LIMITS = {
    "serp_api":      2.0,
    "common_crawl":  2.0,
    "github":        2.5,
    "reddit":        1.5,
    "open_pagerank": 0.05,   # batches of 100, very fast
    "http_check":    1.0,
    "whois":         0.8,
    "wayback":       0.5,
}


# ── Discovery Settings ────────────────────────────────────────────────────────
# Max results per source per link type per run
CC_RESULTS_PER_PATTERN   = 50    # Common Crawl CDX per URL pattern
SERP_RESULTS_PER_QUERY   = 10    # SerpAPI results per search
GITHUB_RESULTS_PER_QUERY = 20    # GitHub search results per query
REDDIT_RESULTS_PER_QUERY = 25    # Reddit posts per subreddit search

# Monthly SerpAPI budget guard (hard cap before switching to CC-only)
SERPAPI_MONTHLY_BUDGET   = 95    # alert/fallback at 95 of 100 free/month

# Common Crawl — use most recent crawl index
CC_INDEX = "CC-MAIN-2025-13"     # update quarterly


# ── Assessment Settings ───────────────────────────────────────────────────────
OPR_BATCH_SIZE      = 100        # domains per Open PageRank API call
HTTP_TIMEOUT_SEC    = 10
HTTP_MAX_REDIRECTS  = 3

# Scoring weights (must sum to 100)
SCORE_WEIGHTS = {
    "authority":    30,   # Open PageRank
    "age":          20,   # Domain age
    "relevance":    25,   # Keyword match
    "opportunity":  15,   # Has submission/contact page
    "health":       10,   # HTTP status, speed
}

# Priority tier thresholds
TIER_THRESHOLDS = {
    "A": 80,
    "B": 60,
    "C": 40,
    # below 40 = D
}


# ── Link Type Categories ──────────────────────────────────────────────────────
LINK_TYPES = [
    "Directories",
    "Local Citations",
    "Profile Links",
    "Social Bookmarking",
    "PDF Sharing",
    "PPT Sharing",
    "Image Sharing",
    "Web 2.0",
    "Forums",
    "Blog Comments",
    "Q&A",
    "Wiki Links",
    "Parasite SEO",
    "Guest Posts",
    "Niche Edits",
    "Editorial Links",
]


# ── Validation ────────────────────────────────────────────────────────────────
def validate_keys() -> dict:
    """
    Check which API keys are configured.
    Returns dict of {service: bool}.
    """
    return {
        "serpapi":      bool(SERPAPI_KEY),
        "open_pagerank": bool(OPR_KEY),
        "reddit":       bool(REDDIT_CLIENT_ID and REDDIT_CLIENT_SECRET),
        "github":       bool(GITHUB_TOKEN),
        "common_crawl": True,   # no key needed
        "wayback":      True,   # no key needed
    }


if __name__ == "__main__":
    status = validate_keys()
    print("API Key Status:")
    for svc, ok in status.items():
        icon = "✓" if ok else "✗ (missing)"
        print(f"  {svc:20s}: {icon}")
