# Scout — Zero-Cost Link Opportunity Pipeline

Discovers, categorises, and scores 500+ link-building opportunities per run using only free APIs. Runs entirely on your local Windows machine. No subscriptions, no cloud, no data leaving your computer.

---

## What it does

1. **Discover** — queries Common Crawl CDX, SerpAPI, GitHub, and Reddit across all 16 link-type categories using templated footprint queries.
2. **Assess** — scores every discovered URL 0–100 using Open PageRank, domain age (WHOIS + Wayback), live HTTP checks, and keyword relevance.
3. **Export** — outputs a prioritised, colour-coded Excel file + CSV ready to import into any outreach CRM.

### 16 Link Type Categories
Directories · Local Citations · Profile Links · Social Bookmarking · PDF Sharing · PPT Sharing · Image Sharing · Web 2.0 · Forums · Blog Comments · Q&A · Wiki Links · Parasite SEO · Guest Posts · Niche Edits · Editorial Links

---

## Quick Start (Windows)

### Step 1 — Install Python 3.11
1. Download: https://python.org/downloads — choose **Python 3.11.x Windows 64-bit**
2. Run the installer — **check "Add Python to PATH"** before clicking Install
3. Verify: open Command Prompt → `python --version`

### Step 2 — Get the Scout folder
Copy the `scout/` folder anywhere on your PC, e.g. `C:\Scout\`

### Step 3 — Create virtual environment
```cmd
cd C:\Scout
python -m venv venv
venv\Scripts\activate
```
You'll see `(venv)` in your prompt. **Always activate before running Scout.**

### Step 4 — Install dependencies
```cmd
pip install -r requirements.txt
```

### Step 5 — Configure API keys
```cmd
copy .env.example .env
notepad .env
```
Fill in your keys (see Step 7 below for how to get each one free).

### Step 6 — Run your first discovery
```cmd
python scout.py discover
```
Follow the prompts. Enter client name, URL, keywords, category, location.

### Step 7 — Get your free API keys

**SerpAPI** (100 free searches/month)
- Go to: https://serpapi.com/users/sign_up
- No credit card. Dashboard → API Key → paste into `.env` as `SERPAPI_KEY`

**Open PageRank** (10,000 free requests/hour — permanently free)
- Go to: https://www.domcop.com/openpagerank/
- Click "Sign Up For Free" → verify email → Dashboard → API Key → `OPR_KEY`

**Reddit API** (free for personal use)
- Log into reddit.com → https://www.reddit.com/prefs/apps
- Click "create another app" → select **script**
- Name: `scout_link_tool` | redirect: `http://localhost:8080`
- Copy **client_id** (under the app name) → `REDDIT_CLIENT_ID`
- Copy **secret** → `REDDIT_CLIENT_SECRET`
- Set `REDDIT_USER_AGENT=scout:v1.0 (by /u/YOUR_REDDIT_USERNAME)`

**GitHub Personal Access Token** (free)
- github.com → Settings → Developer Settings → Personal Access Tokens → Tokens (classic)
- Generate new token (classic) → check **public_repo** → copy → `GITHUB_TOKEN`

---

## All Commands

```cmd
# Create new project and run discovery
python scout.py discover

# Resume an existing project
python scout.py discover --project-id 1

# Run discovery for specific link types only
python scout.py discover --link-types "Guest Posts" --link-types "Niche Edits"

# Disable specific sources
python scout.py discover --no-serp      # skip SerpAPI (preserve monthly budget)
python scout.py discover --no-cdx       # skip Common Crawl

# Assess all unscored opportunities
python scout.py assess

# Assess only first 50 (test run)
python scout.py assess --project-id 1 --limit 50

# Export all results (CSV + Excel)
python scout.py export --project-id 1

# Export filtered
python scout.py export --project-id 1 --tier A
python scout.py export --project-id 1 --type "Guest Posts"
python scout.py export --project-id 1 --format csv

# Print terminal summary
python scout.py report --project-id 1

# List all projects
python scout.py projects

# Check API key status
python scout.py status

# Update opportunity workflow status
python scout.py update --project-id 1 --opp-id 42 --status submitted
python scout.py update --project-id 1 --opp-id 42 --status live --notes "went live 2026-06-10"
```

---

## Workflow Status Values

| Status | Meaning |
|---|---|
| `discovered` | Found in discovery run, not yet assessed |
| `assessed` | Scored by assessment engine |
| `queued` | Marked for outreach |
| `submitted` | Pitch/submission sent |
| `live` | Link confirmed live |
| `rejected` | Rejected or not suitable |

---

## Priority Tiers

| Tier | Score | Action |
|---|---|---|
| **A** | 80–100 | Submit this week |
| **B** | 60–79 | Submit this month |
| **C** | 40–59 | Batch outreach |
| **D** | < 40 | Skip or verify manually |

---

## Scoring Breakdown (0–100)

| Component | Max Points | Source |
|---|---|---|
| Authority | 30 | Open PageRank (0–10 × 3) |
| Domain Age | 20 | WHOIS + Wayback Machine |
| Relevance | 25 | Keyword match in domain/path/title/meta |
| Opportunity | 15 | Has submission page (10) or contact page (5) |
| Health | 10 | HTTP 200, no redirect, fast load |

---

## Free Tier Limits & Budget Management

| Source | Free Limit | Scout's Usage |
|---|---|---|
| Common Crawl CDX | Unlimited (rate-limited) | 50 results per URL pattern |
| SerpAPI | 100/month | Budget-guarded — stops at 95/month |
| GitHub Search API | 30 req/min | 2 queries per link type |
| Reddit API | ~60 req/min | 2 queries × 4 subreddits per link type |
| Open PageRank | 10,000/hr | Batched 100 domains per API call |
| Wayback Machine | Unlimited | Used as domain age fallback |
| WHOIS | Unlimited (soft) | 0.8s sleep between calls |

---

## File Locations

```
scout/
├── databases/          ← SQLite DB files (one per project)
├── exports/            ← CSV + Excel exports
├── logs/               ← scout.log (rotated daily)
├── .env                ← your API keys (never share this file)
└── .env.example        ← template for .env
```

---

## Troubleshooting

**`python` not found after install**
→ Re-open Command Prompt after installation. Or use `py` instead of `python`.

**`venv\Scripts\activate` is not recognised**
→ Run PowerShell as Administrator and execute: `Set-ExecutionPolicy RemoteSigned`

**SerpAPI returns 0 results**
→ Check `python scout.py status` — verify `SERPAPI_KEY` is set. Check monthly usage.

**All scores are 0 / D tier**
→ This happens when `OPR_KEY` is missing. Get a free key at domcop.com/openpagerank and add it to `.env`.

**Common Crawl returns no results**
→ CC CDX is rate-limited. Add a longer sleep: in `config.py` set `"common_crawl": 5.0`

**WHOIS lookups fail**
→ Normal for many domains — Scout automatically falls back to Wayback Machine for domain age.

---

## Adding More Link Types

1. Add a new class in `discovery/footprints.py` (copy an existing class as template)
2. Register it in `LINK_TYPE_CLASSES` at the bottom of `footprints.py`
3. Add the name to `config.LINK_TYPES`
4. Run `python scout.py discover --link-types "Your New Type"`
