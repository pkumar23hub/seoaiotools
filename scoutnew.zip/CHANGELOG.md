# Scout — Changelog

All notable changes documented here. Format: [version] date — description.

---

## [1.0.0] 2026-06-01 — Initial Build

### Added
- **Foundation (Layer 0)**
  - `config.py` — centralised settings, API keys via .env, rate limit table, scoring weights
  - `utils/logger.py` — dual-output logger (console INFO+, file DEBUG+, daily rotation)
  - `utils/helpers.py` — URL normalisation, domain extraction, URL hashing, keyword utilities, rate sleep, chunking
  - `storage/database.py` — SQLite schema (projects, opportunities, run_log, serp_budget), full CRUD, dedup via url_hash UNIQUE constraint
  - `inputs.py` — interactive CLI input collection with validation and confirmation

- **Discovery Sources (Layer 1)**
  - `discovery/sources/common_crawl.py` — CC CDX API, multi-index queries, URL pattern search, graceful 503 handling
  - `discovery/sources/serp_api.py` — SerpAPI Google search, monthly budget guard, rate limiting
  - `discovery/sources/github_search.py` — GitHub repo search + README URL extraction, rate limit handling
  - `discovery/sources/reddit_api.py` — Public Reddit JSON (no OAuth required), URL extraction from post bodies

- **Discovery Engine (Layer 2)**
  - `discovery/footprints.py` — Complete footprint template library for all 16 link types (5 SERP queries + CDX patterns + GitHub queries + Reddit queries per type)
  - `discovery/engine.py` — Orchestrator: runs all 4 sources per link type, global dedup, cross-run hash pre-loading, DB insertion, run logging

- **Assessment Engine (Layer 3)**
  - `assessment/metrics/open_pagerank.py` — OPR API batch (100 domains/call), fallback zeros on missing key
  - `assessment/metrics/domain_age.py` — WHOIS primary, Wayback CDX fallback for domain creation date
  - `assessment/metrics/http_check.py` — Live HTTP check: status, redirect, load time, submission/contact page probing, parked domain detection, title/meta extraction
  - `assessment/metrics/relevance.py` — Keyword match scoring with flat-domain matching (handles concatenated domains like `personalinjurylawyer.com`)
  - `assessment/scorer.py` — Composite 0–100 score: Authority(30) + Age(20) + Relevance(25) + Opportunity(15) + Health(10). Tier assignment A/B/C/D.
  - `assessment/engine.py` — Batch OPR pre-fetch, per-URL pipeline, DB update, run logging

- **Output Layer (Layer 4)**
  - `storage/export.py` — CSV export (UTF-8 BOM for Excel compatibility) + Excel export (3 sheets: All/Tier-A/Pivot, conditional tier colouring, frozen headers)
  - `reports/reporter.py` — Rich terminal tables for discovery summary, assessment results, project list, API key status. Plain-text fallback if Rich unavailable.
  - `main.py` — Click CLI with 7 commands: discover, assess, export, report, projects, status, update

- **Documentation**
  - `README.md` — User setup guide, all commands, troubleshooting
  - `ARCHITECTURE.md` — Module dependency graph, interfaces, extension guides
  - `CHANGELOG.md` — This file
  - `SCOUT_SPEC.md` — Original product specification

- **Config files**
  - `requirements.txt` — Pinned dependency versions
  - `.env.example` — API key template

### Bug Fixes (during build)
- `utils/helpers.py` — `normalize_url()` now forces `https://` scheme and strips `www.` so `url_hash("http://www.example.com") == url_hash("https://example.com")`
- `assessment/metrics/relevance.py` — Added flat-domain matching (`_count_flat_hits`) so multi-word keywords match concatenated domain names (e.g. `"personal injury lawyer"` → `personalinjurylawyer.com`)
- `main.py` — Moved `Optional` import to top-level to fix `NameError` at module load

### Known Limitations
- All scores are 0/D when run without network access (expected — assessment requires live HTTP + API calls)
- Common Crawl CDX `databases/` directory has filesystem lock in sandbox environment — use a separate temp path in tests
- SerpAPI `.env` multi-line values require proper line endings (Windows Notepad saves correctly; avoid Unix tools that may corrupt line endings)

---

## [1.0.2] 2026-06-01 — Installer encoding fix

### Fixed
- `SETUP.bat` — rewritten as pure ASCII with CRLF line endings and no BOM
  - Root cause: Write tool had saved previous version as UTF-8; Windows CMD reads batch files in system ANSI codepage (CP1252/CP437), causing multi-byte UTF-8 box-drawing characters (`─`, `╭`, `│`) to split lines and execute fragments as commands
  - All Unicode box-drawing characters replaced with ASCII equivalents (`=`, `-`, `::`)
  - File now written via Python `open(..., encoding='ascii', newline='\r\n')` to guarantee correct format
  - Embedded Python verification script extracted to standalone `_verify.py` — eliminates escaping complexity in batch heredocs
- `_verify.py` — new standalone 25-test verification script (replaces inline Python in SETUP.bat)
  - Covers all 20 modules + logic + DB + scoring
  - Called by SETUP.bat Step 7; can also be run standalone: `python _verify.py`

---

## [1.0.1] 2026-06-01 — Installer

### Added
- `SETUP.bat` — self-contained Windows installer (701 lines, superseded by v1.0.2)
  - Auto-detects Python via `python`, `python3`, `py` — works on any Windows setup
  - Python version gate: blocks Python < 3.9, clear error message with download link
  - pip presence check with auto-install via `ensurepip` fallback
  - Virtual environment creation with `--repair` flag to nuke and rebuild
  - Pip install with silent first-pass + `--no-cache-dir` retry on failure
  - Package import verification after install (click, rich, httpx, praw, openpyxl, pandas, bs4, dotenv)
  - Creates `databases\`, `exports\`, `logs\` directories
  - Interactive API key prompts with step-by-step instructions per service
  - Writes `.env` file from user input; skippable with `--skip-keys`
  - 25-test verification suite covering all 20 modules + logic + DB + scoring
  - Generates `scout.bat` launcher (activate venv + run main.py with any args)
  - Generates `repair.bat` shortcut
  - Flags: `--debug` (verbose pip output), `--skip-keys`, `--repair`, `--help`
  - Full `setup_log.txt` written throughout; referenced in all error messages
  - Error counter — non-zero exit code on failures, warning-only exit on soft issues

---

## Roadmap (Future Versions)

### [1.1.0] Planned
- Wappalyzer integration for CMS/tech stack detection per domain
- Competitor backlink gap module (CC CDX reverse-lookup)
- Citation gap checker (hardcoded top-150 citation sites)
- Unlinked brand mention finder (Reddit + CC CDX)

### [1.2.0] Planned
- Majestic Million CSV integration (free top-1M domain TF/CF scores)
- Batch submission tracker with CSV import
- Session resume checkpoint (skip already-completed link types on restart)

### [2.0.0] Planned
- Optional FastAPI web UI layer (local dashboard, no cloud)
- Async HTTP assessment (httpx AsyncClient — 5–10× faster bulk checks)
- DataForSEO SERP integration (pay-per-use, ~$0.0006/query for higher volume)
