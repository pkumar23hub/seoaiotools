"""
main.py — Scout CLI entry point.

Commands:
  discover   — Run discovery engine (all 16 link types × 4 sources)
  assess     — Run assessment engine on all unscored opportunities
  export     — Export results to CSV + Excel
  report     — Print terminal summary for a project
  projects   — List all existing projects
  status     — Show API key configuration status
  update     — Update opportunity workflow status

Usage examples:
  python scout.py discover
  python scout.py discover --project-id 1
  python scout.py assess --project-id 1
  python scout.py export --project-id 1
  python scout.py export --project-id 1 --tier A
  python scout.py export --project-id 1 --type "Guest Posts"
  python scout.py report --project-id 1
  python scout.py projects
  python scout.py status
  python scout.py update --project-id 1 --opp-id 42 --status submitted
"""

import sys
import os
from pathlib import Path

# Ensure scout/ is on sys.path regardless of where script is called from
sys.path.insert(0, str(Path(__file__).parent))

import click
from typing import Optional
from utils.logger import get_logger
import config

logger = get_logger(__name__)


# ── Shared helpers ─────────────────────────────────────────────────────────────

def _get_db_and_project(project_id: int):
    """Open DB and load project. Exits on failure."""
    from storage.database import Database

    # Find DB for this project_id (scan all DBs in DB_DIR)
    db_files = list(config.DB_DIR.glob("scout_*.db"))
    if not db_files:
        click.echo("No projects found. Run 'python scout.py discover' to start.", err=True)
        sys.exit(1)

    # Try each DB until we find the project_id
    for db_file in db_files:
        db = Database(db_path=db_file)
        db.connect()
        p = db.get_project(project_id)
        if p:
            return db, p
        db.close()

    click.echo(f"Project #{project_id} not found.", err=True)
    sys.exit(1)


def _resolve_project_id(project_id: Optional[int]) -> tuple:
    """If no project_id given, list projects and ask user to choose."""
    from storage.database import Database
    from reports.reporter import print_projects_table

    if project_id is not None:
        return _get_db_and_project(project_id)

    # Find all projects across all DBs
    all_projects = []
    db_files = list(config.DB_DIR.glob("scout_*.db"))
    for db_file in db_files:
        db = Database(db_path=db_file)
        db.connect()
        for p in db.list_projects():
            p["_db_file"] = str(db_file)
            all_projects.append(p)
        db.close()

    if not all_projects:
        return None, None

    if len(all_projects) == 1:
        db = Database(db_path=Path(all_projects[0]["_db_file"]))
        db.connect()
        return db, db.get_project(all_projects[0]["id"])

    print_projects_table(all_projects)
    pid = click.prompt("\nEnter project ID", type=int)
    return _get_db_and_project(pid)


# ── CLI Group ──────────────────────────────────────────────────────────────────

@click.group()
def cli():
    """Scout — Zero-Cost Link Opportunity Discovery Tool"""
    pass


# ── discover ──────────────────────────────────────────────────────────────────

@cli.command()
@click.option("--project-id", "-p", type=int, default=None,
              help="Resume existing project by ID. Omit to create new project.")
@click.option("--link-types", "-l", multiple=True,
              help="Specific link types to run (can repeat). Default: all 16.")
@click.option("--sources", "-s", multiple=True,
              help="Sources to use: cdx, serp, github, reddit. Default: all.")
@click.option("--no-cdx",    is_flag=True, help="Skip Common Crawl CDX queries.")
@click.option("--no-serp",   is_flag=True, help="Skip SerpAPI queries.")
@click.option("--no-github", is_flag=True, help="Skip GitHub queries.")
@click.option("--no-reddit", is_flag=True, help="Skip Reddit queries.")
def discover(project_id, link_types, sources, no_cdx, no_serp, no_github, no_reddit):
    """Discover link opportunities across all 16 link types."""
    from storage.database import Database
    from inputs import collect_project_inputs, project_to_slug, get_keyword_set
    from discovery.engine import DiscoveryEngine
    from reports.reporter import print_discovery_summary
    import config as cfg

    # Check API key status first
    key_status = cfg.validate_keys()
    _warn_missing_keys(key_status)

    # Resolve sources list
    active_sources = list(sources) if sources else ["cdx", "serp", "github", "reddit"]
    if no_cdx    and "cdx"    in active_sources: active_sources.remove("cdx")
    if no_serp   and "serp"   in active_sources: active_sources.remove("serp")
    if no_github and "github" in active_sources: active_sources.remove("github")
    if no_reddit and "reddit" in active_sources: active_sources.remove("reddit")

    if not active_sources:
        click.echo("Error: at least one source must be enabled.", err=True)
        sys.exit(1)

    # Load or create project
    if project_id is not None:
        db, project = _get_db_and_project(project_id)
        click.echo(f"\nResuming project #{project_id}: {project['client_name']}")
    else:
        try:
            p_inputs = collect_project_inputs()
        except KeyboardInterrupt:
            click.echo("\nCancelled.")
            sys.exit(0)

        slug = project_to_slug(p_inputs)
        db = Database(project_slug=slug)
        db.connect()
        pid = db.create_project(p_inputs)
        project = db.get_project(pid)

    keywords = _build_keywords(project)
    link_type_list = list(link_types) if link_types else None

    click.echo(f"\nSources: {active_sources}")
    click.echo(f"Keywords: {keywords[:3]}...")
    click.echo()

    engine = DiscoveryEngine(db, project, keywords)
    total = engine.run(link_types=link_type_list, sources=active_sources)

    by_type = db.count_by_link_type(project["id"])
    serp_used = db.get_serp_usage()
    print_discovery_summary(project, by_type, total, serp_used)

    db.close()


# ── assess ────────────────────────────────────────────────────────────────────

@cli.command()
@click.option("--project-id", "-p", type=int, default=None)
@click.option("--limit", "-n", type=int, default=0,
              help="Max opportunities to assess (0 = all).")
def assess(project_id, limit):
    """Assess all unscored opportunities (authority, age, relevance, health)."""
    from assessment.engine import AssessmentEngine
    from reports.reporter import print_assessment_summary

    db, project = _resolve_project_id(project_id)
    if not project:
        click.echo("No projects found. Run 'discover' first.")
        return

    keywords = _build_keywords(project)
    engine = AssessmentEngine(db, project, keywords)
    count = engine.run(limit=limit)

    stats = db.summary_stats(project["id"])
    print_assessment_summary(project, stats)
    db.close()


# ── export ────────────────────────────────────────────────────────────────────

@cli.command()
@click.option("--project-id", "-p", type=int, default=None)
@click.option("--tier",      "-t", type=click.Choice(["A","B","C","D"]), default=None,
              help="Filter by priority tier.")
@click.option("--type",      "link_type", default=None,
              help="Filter by link type (e.g. 'Guest Posts').")
@click.option("--status",    default=None,
              help="Filter by status (discovered/assessed/submitted/live).")
@click.option("--format",    "fmt", type=click.Choice(["csv","excel","both"]),
              default="both", help="Output format.")
def export(project_id, tier, link_type, status, fmt):
    """Export opportunities to CSV and/or Excel."""
    from storage.export import export_csv, export_excel, generate_filename
    import config as cfg

    db, project = _resolve_project_id(project_id)
    if not project:
        click.echo("No projects found.")
        return

    opps = db.get_opportunities(
        project["id"],
        tier=tier,
        link_type=link_type,
        status=status,
    )

    if not opps:
        click.echo("No opportunities match the given filters.")
        db.close()
        return

    click.echo(f"\nExporting {len(opps)} opportunities...")

    if fmt in ("csv", "both"):
        fname = generate_filename(project, ".csv")
        path = cfg.EXPORT_DIR / fname
        out = export_csv(opps, path)
        click.echo(f"CSV: {out}")

    if fmt in ("excel", "both"):
        fname = generate_filename(project, ".xlsx")
        path = cfg.EXPORT_DIR / fname
        out = export_excel(opps, project, path)
        click.echo(f"Excel: {out}")

    db.close()


# ── report ────────────────────────────────────────────────────────────────────

@cli.command()
@click.option("--project-id", "-p", type=int, default=None)
def report(project_id):
    """Print a terminal summary for a project."""
    from reports.reporter import print_discovery_summary, print_assessment_summary

    db, project = _resolve_project_id(project_id)
    if not project:
        click.echo("No projects found.")
        return

    by_type = db.count_by_link_type(project["id"])
    stats   = db.summary_stats(project["id"])
    serp    = db.get_serp_usage()

    print_discovery_summary(project, by_type, stats.get("total", 0), serp)
    print_assessment_summary(project, stats)
    db.close()


# ── projects ──────────────────────────────────────────────────────────────────

@cli.command()
def projects():
    """List all existing Scout projects."""
    from storage.database import Database
    from reports.reporter import print_projects_table

    all_projects = []
    for db_file in config.DB_DIR.glob("scout_*.db"):
        db = Database(db_path=db_file)
        db.connect()
        all_projects.extend(db.list_projects())
        db.close()

    if not all_projects:
        click.echo("No projects yet. Run 'python scout.py discover' to create one.")
    else:
        print_projects_table(all_projects)


# ── status ────────────────────────────────────────────────────────────────────

@cli.command()
def status():
    """Show API key configuration and usage status."""
    from reports.reporter import print_key_status

    key_status = config.validate_keys()
    print_key_status(key_status)

    missing = [k for k, v in key_status.items() if not v]
    if missing:
        click.echo(f"[!] Missing keys: {', '.join(missing)}")
        click.echo("    Edit your .env file and add the missing keys.")
        click.echo("    See README.md → Step 7 for how to get each key.")
    else:
        click.echo("All API keys configured.")


# ── update ────────────────────────────────────────────────────────────────────

@cli.command()
@click.option("--project-id", "-p", type=int, required=True)
@click.option("--opp-id",     "-i", type=int, required=True,
              help="Opportunity ID to update.")
@click.option("--status",     "-s",
              type=click.Choice(["discovered","assessed","queued","submitted","live","rejected"]),
              required=True)
@click.option("--notes",      "-n", default="", help="Optional notes.")
def update(project_id, opp_id, status, notes):
    """Update the workflow status of an opportunity."""
    db, project = _get_db_and_project(project_id)
    db.update_status(opp_id, status, notes)
    click.echo(f"Opportunity #{opp_id} updated to '{status}'")
    db.close()


# ── Helpers ────────────────────────────────────────────────────────────────────

def _build_keywords(project: dict) -> list[str]:
    """Build keyword set from a project dict."""
    from utils.helpers import build_keyword_set
    return build_keyword_set(
        primary   = project.get("primary_kw", ""),
        secondary = [
            project.get("secondary_kw1", ""),
            project.get("secondary_kw2", ""),
            project.get("secondary_kw3", ""),
        ],
        niche     = project.get("category", ""),
        location  = project.get("location", ""),
    )


def _warn_missing_keys(key_status: dict):
    """Print warnings for missing optional API keys."""
    if not key_status.get("serpapi"):
        click.echo("[!] SERPAPI_KEY not set — SERP discovery disabled (CDX-only mode)")
    if not key_status.get("open_pagerank"):
        click.echo("[!] OPR_KEY not set — authority scores will be 0 (get free key at domcop.com/openpagerank)")




if __name__ == "__main__":
    cli()
