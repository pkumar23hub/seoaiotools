"""
reports/reporter.py — Rich terminal reports for Scout.

Renders tables and summaries to the terminal using the Rich library.
Called by main.py after discovery and assessment runs.
"""

from typing import Optional
from utils.logger import get_logger

logger = get_logger(__name__)


def print_discovery_summary(
    project: dict,
    by_link_type: list[dict],
    total_inserted: int,
    serp_usage: int,
):
    """Print a summary table after a discovery run."""
    try:
        from rich.console import Console
        from rich.table import Table
        from rich.panel import Panel
        from rich import box

        console = Console()

        console.print()
        console.print(Panel(
            f"[bold cyan]Scout Discovery Complete[/bold cyan]\n"
            f"Client: [yellow]{project['client_name']}[/yellow]  |  "
            f"URL: [blue]{project['project_url']}[/blue]\n"
            f"SerpAPI used this month: [{'red' if serp_usage > 80 else 'green'}]{serp_usage}/100[/]",
            title="[bold]Discovery Run[/bold]",
            border_style="cyan",
        ))

        table = Table(box=box.ROUNDED, border_style="dim")
        table.add_column("Link Type",     style="cyan",    min_width=20)
        table.add_column("Total Found",   justify="right", style="green")
        table.add_column("Assessed",      justify="right", style="yellow")
        table.add_column("Tier A",        justify="right", style="bold green")
        table.add_column("Tier B",        justify="right", style="green")

        for row in by_link_type:
            table.add_row(
                row["link_type"],
                str(row["total"]),
                str(row["assessed"]),
                str(row["tier_a"]),
                str(row["tier_b"]),
            )

        console.print(table)
        console.print(f"\n[bold green]Total new opportunities:[/bold green] {total_inserted}")

    except ImportError:
        # Fallback plain text
        print(f"\n=== Discovery Complete: {total_inserted} new opportunities ===")
        for row in by_link_type:
            print(f"  {row['link_type']:25s}: {row['total']} found")


def print_assessment_summary(project: dict, stats: dict):
    """Print a summary table after an assessment run."""
    try:
        from rich.console import Console
        from rich.panel import Panel
        from rich.table import Table
        from rich import box

        console = Console()
        console.print()

        tier_a = stats.get("tier_a") or 0
        tier_b = stats.get("tier_b") or 0
        tier_c = stats.get("tier_c") or 0
        tier_d = stats.get("tier_d") or 0
        total  = stats.get("total") or 0
        avg    = stats.get("avg_score") or 0

        console.print(Panel(
            f"[bold cyan]Assessment Complete[/bold cyan]\n"
            f"Client: [yellow]{project['client_name']}[/yellow]\n"
            f"Average Score: [bold]{avg}[/bold] / 100",
            title="[bold]Assessment Results[/bold]",
            border_style="cyan",
        ))

        table = Table(box=box.ROUNDED, border_style="dim")
        table.add_column("Tier",        style="bold", min_width=8)
        table.add_column("Count",       justify="right")
        table.add_column("Description", style="dim")

        table.add_row("[bold green]A[/]",   str(tier_a), "Priority — submit this week",   style="on dark_green" if tier_a else "")
        table.add_row("[yellow]B[/]",       str(tier_b), "Good — submit this month")
        table.add_row("[orange1]C[/]",      str(tier_c), "Medium — batch outreach")
        table.add_row("[red]D[/]",          str(tier_d), "Low — skip or verify manually")
        table.add_row("[bold]Total[/bold]", str(total),  "")

        console.print(table)
        console.print(
            "\n[dim]Run [bold]python scout.py export[/bold] to save results to CSV/Excel[/dim]"
        )

    except ImportError:
        print(f"\n=== Assessment Complete ===")
        print(f"  Tier A: {stats.get('tier_a',0)}")
        print(f"  Tier B: {stats.get('tier_b',0)}")
        print(f"  Total:  {stats.get('total',0)}")


def print_projects_table(projects: list[dict]):
    """Print existing projects list."""
    try:
        from rich.console import Console
        from rich.table import Table
        from rich import box

        console = Console()
        table = Table(title="Existing Projects", box=box.ROUNDED)
        table.add_column("ID",         style="cyan",   justify="right")
        table.add_column("Client",     style="yellow")
        table.add_column("URL",        style="blue")
        table.add_column("Created",    style="dim")

        for p in projects:
            table.add_row(
                str(p["id"]),
                p["client_name"],
                p["project_url"],
                (p.get("created_at") or "")[:10],
            )
        console.print(table)

    except ImportError:
        for p in projects:
            print(f"  #{p['id']}: {p['client_name']} ({p['project_url']})")


def print_key_status(key_status: dict):
    """Print API key configuration status."""
    try:
        from rich.console import Console
        console = Console()
        console.print("\n[bold]API Key Status:[/bold]")
        for svc, ok in key_status.items():
            icon = "[green]✓[/green]" if ok else "[red]✗ missing[/red]"
            console.print(f"  {svc:20s}: {icon}")
        console.print()
    except ImportError:
        for svc, ok in key_status.items():
            print(f"  {svc}: {'OK' if ok else 'MISSING'}")


if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")

    # Test with mock data
    mock_project = {"client_name": "Test Client", "project_url": "https://test.com", "id": 1}
    mock_stats = {"total": 487, "assessed": 320, "tier_a": 42, "tier_b": 98,
                  "tier_c": 120, "tier_d": 60, "avg_score": 58.3}
    mock_by_type = [
        {"link_type": "Guest Posts", "total": 47, "assessed": 30, "tier_a": 8, "tier_b": 15},
        {"link_type": "Niche Edits", "total": 41, "assessed": 25, "tier_a": 6, "tier_b": 12},
        {"link_type": "Directories", "total": 38, "assessed": 20, "tier_a": 3, "tier_b": 9},
    ]

    print_discovery_summary(mock_project, mock_by_type, 487, 23)
    print_assessment_summary(mock_project, mock_stats)
    print_key_status({"serpapi": True, "open_pagerank": False, "reddit": True, "github": True})
    print("Reporter test PASSED")
