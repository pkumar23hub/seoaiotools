"""
assessment/metrics/http_check.py — Live HTTP check for a URL.

Checks:
  - HTTP response code (200 = good, 4xx/5xx = bad)
  - Redirect presence and final URL
  - Response time in ms
  - Whether page has a contact/submission page (via path probing)
  - Parked domain detection (title/body signals)
  - Page title and meta description extraction

Uses httpx (async-capable, better than requests for bulk checks).
Falls back to requests if httpx unavailable.
"""

import time
import re
from typing import Optional
from urllib.parse import urljoin, urlparse

from utils.logger import get_logger
from utils.helpers import sleep_rate, extract_domain

logger = get_logger(__name__)

# Paths to probe for submission/contact pages
SUBMISSION_PATHS = [
    "/write-for-us", "/write-for-us/", "/guest-post", "/guest-post/",
    "/contribute", "/contribute/", "/submission-guidelines",
    "/submit-article", "/submit", "/become-a-contributor",
]
CONTACT_PATHS = [
    "/contact", "/contact/", "/contact-us", "/about", "/about-us",
]

# Parked domain signals in page title or body
PARKED_SIGNALS = [
    "domain for sale", "buy this domain", "parked domain",
    "this domain", "domain parking", "godaddy.com/domains",
    "sedoparking.com", "register this domain", "domain may be for sale",
]


def check_url(url: str) -> dict:
    """
    Perform HTTP check on a URL.

    Returns dict with:
        http_status, is_redirect, final_url, response_time_ms,
        has_contact_page, has_submission_page, is_parked,
        page_title, meta_description
    """
    result = {
        "http_status":         None,
        "is_redirect":         False,
        "final_url":           url,
        "response_time_ms":    None,
        "has_contact_page":    False,
        "has_submission_page": False,
        "is_parked":           False,
        "page_title":          None,
        "meta_description":    None,
    }

    try:
        import httpx
        _check_with_httpx(url, result)
    except ImportError:
        import requests as req_lib
        _check_with_requests(url, result, req_lib)
    except Exception as e:
        logger.debug(f"HTTP check failed for {url}: {e}")

    sleep_rate("http_check")
    return result


def _check_with_httpx(url: str, result: dict):
    import httpx
    import config

    headers = {"User-Agent": "Mozilla/5.0 (Scout/1.0) link research bot"}
    start = time.time()

    try:
        with httpx.Client(
            timeout=config.HTTP_TIMEOUT_SEC,
            max_redirects=config.HTTP_MAX_REDIRECTS,
            follow_redirects=True,
            headers=headers,
        ) as client:
            resp = client.get(url)

        elapsed = int((time.time() - start) * 1000)
        result["http_status"]      = resp.status_code
        result["response_time_ms"] = elapsed
        result["final_url"]        = str(resp.url)
        result["is_redirect"]      = str(resp.url) != url

        if resp.status_code == 200:
            html = resp.text
            result["page_title"]       = _extract_title(html)
            result["meta_description"] = _extract_meta_desc(html)
            result["is_parked"]        = _detect_parked(html, result["page_title"])

            base_url = str(resp.url).rstrip("/")
            result["has_contact_page"]    = _probe_paths(client, base_url, CONTACT_PATHS)
            result["has_submission_page"] = _probe_paths(client, base_url, SUBMISSION_PATHS)

    except httpx.TooManyRedirects:
        result["http_status"] = 310
        result["is_redirect"] = True
    except httpx.ConnectError:
        result["http_status"] = 0
    except httpx.TimeoutException:
        result["http_status"] = -1


def _check_with_requests(url: str, result: dict, req_lib):
    import config

    headers = {"User-Agent": "Mozilla/5.0 (Scout/1.0) link research bot"}
    start = time.time()

    try:
        resp = req_lib.get(
            url,
            headers=headers,
            timeout=config.HTTP_TIMEOUT_SEC,
            allow_redirects=True,
        )
        elapsed = int((time.time() - start) * 1000)
        result["http_status"]      = resp.status_code
        result["response_time_ms"] = elapsed
        result["final_url"]        = resp.url
        result["is_redirect"]      = resp.url != url

        if resp.status_code == 200:
            html = resp.text
            result["page_title"]       = _extract_title(html)
            result["meta_description"] = _extract_meta_desc(html)
            result["is_parked"]        = _detect_parked(html, result["page_title"])

    except req_lib.exceptions.ConnectionError:
        result["http_status"] = 0
    except req_lib.exceptions.Timeout:
        result["http_status"] = -1
    except Exception as e:
        logger.debug(f"requests check error: {e}")


def _probe_paths(client, base_url: str, paths: list[str]) -> bool:
    """Check if any of the given paths return a 200 response."""
    for path in paths:
        try:
            resp = client.get(base_url + path, follow_redirects=True)
            if resp.status_code == 200:
                return True
        except Exception:
            continue
    return False


def _extract_title(html: str) -> Optional[str]:
    m = re.search(r"<title[^>]*>(.*?)</title>", html, re.IGNORECASE | re.DOTALL)
    if m:
        return re.sub(r"\s+", " ", m.group(1)).strip()[:200]
    return None


def _extract_meta_desc(html: str) -> Optional[str]:
    m = re.search(
        r'<meta\s+name=["\']description["\']\s+content=["\'](.*?)["\']',
        html, re.IGNORECASE
    )
    if not m:
        m = re.search(
            r'<meta\s+content=["\'](.*?)["\']\s+name=["\']description["\']',
            html, re.IGNORECASE
        )
    if m:
        return m.group(1).strip()[:300]
    return None


def _detect_parked(html: str, title: Optional[str]) -> bool:
    check_text = (html[:2000] + " " + (title or "")).lower()
    return any(signal in check_text for signal in PARKED_SIGNALS)


if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")

    print("Testing HTTP check on example.com...")
    r = check_url("https://example.com")
    print(f"  Status: {r['http_status']}")
    print(f"  Title: {r['page_title']}")
    print(f"  Parked: {r['is_parked']}")
    print(f"  Response time: {r['response_time_ms']}ms")

    if r["http_status"] == 200:
        assert not r["is_parked"]
        print("HTTP check test PASSED")
    else:
        print(f"HTTP check test skipped (no network, status={r['http_status']})")
