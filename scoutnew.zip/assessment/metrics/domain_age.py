"""
assessment/metrics/domain_age.py — Domain age via WHOIS.

Uses python-whois to look up registration date.
Falls back to Wayback Machine first_seen if WHOIS fails or is blocked.

Returns: domain_created (ISO date string), domain_age_years (float)
"""

import time
from datetime import datetime, timezone
from typing import Optional

from utils.logger import get_logger
from utils.helpers import sleep_rate

logger = get_logger(__name__)


def get_domain_age(domain: str) -> dict:
    """
    Look up domain creation date.

    Returns:
        {domain_created: str|None, domain_age_years: float}
    """
    result = _try_whois(domain)
    if result["domain_created"] is None:
        result = _try_wayback(domain)
    return result


def _try_whois(domain: str) -> dict:
    """Attempt WHOIS lookup for creation date."""
    try:
        import whois
        w = whois.whois(domain)
        created = w.creation_date

        if isinstance(created, list):
            created = created[0]

        if created is None:
            return {"domain_created": None, "domain_age_years": 0.0}

        # Ensure timezone-naive for comparison
        if hasattr(created, "tzinfo") and created.tzinfo:
            created = created.replace(tzinfo=None)

        age_years = (datetime.now() - created).days / 365.25
        sleep_rate("whois")
        return {
            "domain_created":    created.strftime("%Y-%m-%d"),
            "domain_age_years":  round(max(0.0, age_years), 2),
        }

    except Exception as e:
        logger.debug(f"WHOIS failed for {domain}: {e}")
        return {"domain_created": None, "domain_age_years": 0.0}


def _try_wayback(domain: str) -> dict:
    """Use Wayback Machine CDX to estimate domain age from first crawl."""
    try:
        import requests
        resp = requests.get(
            "http://web.archive.org/cdx/search/cdx",
            params={
                "url":    f"{domain}/*",
                "output": "json",
                "limit":  1,
                "fl":     "timestamp",
                "from":   "19960101",
                "to":     "20251231",
            },
            timeout=10,
        )
        if resp.status_code != 200:
            return {"domain_created": None, "domain_age_years": 0.0}

        data = resp.json()
        if len(data) < 2:  # first row is header ["timestamp"]
            return {"domain_created": None, "domain_age_years": 0.0}

        ts = data[1][0]  # e.g. "19991015134512"
        created = datetime.strptime(ts[:8], "%Y%m%d")
        age_years = (datetime.now() - created).days / 365.25
        sleep_rate("wayback")
        return {
            "domain_created":   created.strftime("%Y-%m-%d"),
            "domain_age_years": round(max(0.0, age_years), 2),
        }

    except Exception as e:
        logger.debug(f"Wayback age lookup failed for {domain}: {e}")
        return {"domain_created": None, "domain_age_years": 0.0}


if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")

    # Test with a well-known domain
    result = get_domain_age("example.com")
    print(f"example.com: {result}")
    # example.com registered in 1995
    if result["domain_age_years"] > 0:
        assert result["domain_age_years"] > 20, "example.com should be 20+ years old"
    print("Domain age test complete")
