"""
assessment/metrics/relevance.py — Keyword relevance scorer.

Scores how relevant a discovered URL is to the project's keyword set.
Pure string matching — no external API needed.

Scoring signals:
  - Keyword in domain name (strongest signal)
  - Keyword in URL path
  - Keyword in page title
  - Keyword in meta description
  - Niche/category match anywhere

Returns: relevance_score (float 0.0-10.0)
"""

import re
from typing import Optional

from utils.logger import get_logger
from utils.helpers import extract_domain, count_keyword_hits, keyword_in_text

logger = get_logger(__name__)


def score_relevance(
    url: str,
    keywords: list[str],
    page_title: Optional[str] = None,
    meta_description: Optional[str] = None,
    niche: str = "",
) -> float:
    """
    Compute a relevance score (0.0–10.0) for a URL against project keywords.

    Breakdown (max 10 points):
      Domain match:      0–4  (keyword in domain = 4, partial = 2)
      Path match:        0–2  (keyword in path)
      Title match:       0–2  (keyword in title)
      Meta match:        0–1  (keyword in meta desc)
      Niche match:       0–1  (niche/category in any field)
    """
    if not keywords:
        return 0.0

    domain = extract_domain(url)
    path   = _get_path(url)
    title  = page_title or ""
    meta   = meta_description or ""

    score = 0.0

    # ── Domain match (4 pts) ──────────────────────────────────────────────────
    # Check both normal domain and the domain with spaces/hyphens removed
    # so "personalinjurylawyer.com" matches "personal injury lawyer"
    domain_flat = re.sub(r"[-_.]", "", domain)  # "personalinjurylawyer"
    domain_spaced = re.sub(r"[-_]", " ", domain)  # "personal-injury → personal injury"
    domain_hits = max(
        count_keyword_hits(keywords, domain),
        count_keyword_hits(keywords, domain_spaced),
        _count_flat_hits(keywords, domain_flat),
    )
    if domain_hits >= 2:
        score += 4.0
    elif domain_hits == 1:
        score += 3.0
    elif _partial_match(keywords, domain):
        score += 1.5

    # ── Path match (2 pts) ────────────────────────────────────────────────────
    path_hits = count_keyword_hits(keywords, path)
    if path_hits >= 2:
        score += 2.0
    elif path_hits == 1:
        score += 1.0

    # ── Title match (2 pts) ───────────────────────────────────────────────────
    if title:
        title_hits = count_keyword_hits(keywords, title)
        if title_hits >= 2:
            score += 2.0
        elif title_hits == 1:
            score += 1.0

    # ── Meta description match (1 pt) ─────────────────────────────────────────
    if meta:
        if count_keyword_hits(keywords, meta) >= 1:
            score += 1.0

    # ── Niche match (1 pt) ────────────────────────────────────────────────────
    if niche:
        all_text = f"{domain} {path} {title} {meta}".lower()
        if niche.lower() in all_text:
            score += 1.0

    return round(min(10.0, score), 2)


def _get_path(url: str) -> str:
    """Extract just the path portion of a URL."""
    try:
        from urllib.parse import urlparse
        p = urlparse(url)
        return (p.path + " " + p.query).lower().replace("-", " ").replace("/", " ")
    except Exception:
        return ""


def _count_flat_hits(keywords: list[str], flat_domain: str) -> int:
    """Check keywords against a domain with all separators removed."""
    flat_domain = flat_domain.lower()
    hits = 0
    for kw in keywords:
        kw_flat = re.sub(r"\s+", "", kw.lower())
        if len(kw_flat) >= 4 and kw_flat in flat_domain:
            hits += 1
    return hits


def _partial_match(keywords: list[str], text: str) -> bool:
    """Check if any single word from any keyword appears in text."""
    for kw in keywords:
        for word in kw.lower().split():
            if len(word) > 3 and word in text.lower():
                return True
    return False


if __name__ == "__main__":

    import sys
    sys.path.insert(0, ".")

    keywords = ["personal injury lawyer", "car accident attorney", "Legal"]

    s1 = score_relevance(
        "https://personalinjurylawyer.com/write-for-us",
        keywords,
        page_title="Personal Injury Lawyer Blog - Write for Us",
        niche="Legal",
    )
    print(f"High relevance: {s1}")
    assert s1 >= 3.5, f"Expected >= 3.5, got {s1}"

    s2 = score_relevance(
        "https://genericblog.com/legal-resources",
        keywords,
        page_title="Legal Resources for Injury Victims",
        niche="Legal",
    )
    print(f"Medium relevance: {s2}")

    s3 = score_relevance(
        "https://cookingrecipes.com/desserts",
        keywords,
        page_title="Best Dessert Recipes",
        niche="Legal",
    )
    print(f"Low relevance: {s3}")
    assert s3 <= 2.0, f"Expected <= 2.0, got {s3}"

    print("Relevance scorer tests PASSED")
