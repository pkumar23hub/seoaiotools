"""
assessment/metrics/open_pagerank.py — Open PageRank API metric.

Permanently free API, 10,000 requests/hour.
Batches up to 100 domains per call.
No key required to sign up cost — free registration at domcop.com/openpagerank.

Returns: opr_score (0.0-10.0), opr_rank (integer, lower=better authority)
"""

import requests
import time
from typing import Optional

from utils.logger import get_logger
from utils.helpers import chunk_list, sleep_rate
import config

logger = get_logger(__name__)

OPR_ENDPOINT = "https://openpagerank.com/api/v1.0/getPageRank"


def get_pagerank_batch(domains: list[str]) -> dict[str, dict]:
    """
    Fetch Open PageRank for up to 100 domains in one API call.

    Args:
        domains: List of bare domain strings (e.g. ['example.com', 'site2.com'])

    Returns:
        Dict mapping domain → {opr_score: float, opr_rank: int}
        Missing domains (API error or not indexed) → {opr_score: 0.0, opr_rank: 0}
    """
    if not config.OPR_KEY:
        logger.debug("OPR_KEY not set — returning zero scores")
        return {d: {"opr_score": 0.0, "opr_rank": 0} for d in domains}

    if len(domains) > 100:
        logger.warning("OPR batch limited to 100 — truncating")
        domains = domains[:100]

    params = [("domains[]", d) for d in domains]

    try:
        resp = requests.get(
            OPR_ENDPOINT,
            params=params,
            headers={"API-OPR": config.OPR_KEY},
            timeout=15,
        )
        if resp.status_code == 429:
            logger.warning("OPR rate limited. Sleeping 5s...")
            time.sleep(5)
            return {d: {"opr_score": 0.0, "opr_rank": 0} for d in domains}
        resp.raise_for_status()

        data = resp.json()
        result = {}
        for item in data.get("response", []):
            domain = item.get("domain", "")
            score  = float(item.get("page_rank_decimal", 0) or 0)
            rank   = int(item.get("rank", 0) or 0)
            result[domain] = {"opr_score": score, "opr_rank": rank}

        # Fill in any missing domains
        for d in domains:
            if d not in result:
                result[d] = {"opr_score": 0.0, "opr_rank": 0}

        logger.debug(f"OPR: {len(domains)} domains → {len(result)} scores")
        sleep_rate("open_pagerank")
        return result

    except Exception as e:
        logger.error(f"OPR API error: {e}")
        return {d: {"opr_score": 0.0, "opr_rank": 0} for d in domains}


def get_pagerank_bulk(domains: list[str]) -> dict[str, dict]:
    """
    Fetch Open PageRank for any number of domains, batched automatically.
    """
    results = {}
    for batch in chunk_list(domains, config.OPR_BATCH_SIZE):
        batch_results = get_pagerank_batch(batch)
        results.update(batch_results)
    return results


if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")

    if not config.OPR_KEY:
        print("No OPR_KEY — testing zero-score fallback")
        r = get_pagerank_batch(["example.com", "google.com"])
        assert r["example.com"]["opr_score"] == 0.0
        print("OPR fallback test PASSED")
    else:
        print("Testing OPR API (live)...")
        r = get_pagerank_batch(["google.com", "github.com", "example.com"])
        for d, v in r.items():
            print(f"  {d}: OPR={v['opr_score']}")
        print("OPR test PASSED")
