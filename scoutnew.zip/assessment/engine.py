"""
assessment/engine.py — Main Assessment Engine orchestrator.

Processes all unassessed opportunities in the database:
  1. Batch fetch Open PageRank scores (100 domains per API call)
  2. Per URL: WHOIS domain age → HTTP check → relevance score → composite score
  3. Update DB with all scores and tier assignment

Designed to be run after discovery: python scout.py assess

Usage:
    from assessment.engine import AssessmentEngine
    engine = AssessmentEngine(db, project, keywords)
    count = engine.run()
"""

from typing import Optional

from utils.logger import get_logger
from utils.helpers import extract_domain, chunk_list
from storage.database import Database
from assessment.metrics import open_pagerank, domain_age, http_check, relevance
from assessment.scorer import compute_score
import config

logger = get_logger(__name__)


class AssessmentEngine:
    """
    Orchestrates full assessment pipeline for a project's unassessed opportunities.

    Attributes:
        db       : Database instance (must be connected)
        project  : dict from db.get_project()
        keywords : list of keyword strings
    """

    def __init__(self, db: Database, project: dict, keywords: list[str]):
        self.db       = db
        self.project  = project
        self.project_id = project["id"]
        self.keywords = keywords
        self.niche    = project.get("category", "")

    def run(self, limit: int = 0) -> int:
        """
        Assess all unscored opportunities (status='discovered').

        Args:
            limit: Process at most this many. 0 = all.

        Returns:
            Number of opportunities assessed.
        """
        opps = self.db.get_unassessed(self.project_id, limit=limit)
        if not opps:
            logger.info("No unassessed opportunities found.")
            return 0

        logger.info(f"Assessing {len(opps)} opportunities for project #{self.project_id}")

        run_id = self.db.log_run_start(
            self.project_id, "assessment",
            ["open_pagerank", "whois", "http_check", "relevance"]
        )

        # ── Step 1: Batch Open PageRank for all domains ───────────────────────
        domains = list({extract_domain(o["url"]) for o in opps})
        logger.info(f"Fetching Open PageRank for {len(domains)} unique domains...")
        opr_data = open_pagerank.get_pagerank_bulk(domains)

        # ── Step 2: Assess each opportunity ───────────────────────────────────
        assessed_count = 0
        for i, opp in enumerate(opps, 1):
            url    = opp["url"]
            domain = extract_domain(url)

            logger.info(f"  [{i}/{len(opps)}] {url[:70]}")

            try:
                # OPR (from batch result)
                opr = opr_data.get(domain, {"opr_score": 0.0, "opr_rank": 0})

                # Domain age
                age = domain_age.get_domain_age(domain)

                # HTTP check
                http = http_check.check_url(url)

                # Relevance
                rel_score = relevance.score_relevance(
                    url          = url,
                    keywords     = self.keywords,
                    page_title   = http.get("page_title"),
                    meta_description = http.get("meta_description"),
                    niche        = self.niche,
                )

                # Composite score
                total, tier = compute_score(
                    opr_score           = opr["opr_score"],
                    domain_age_years    = age["domain_age_years"],
                    relevance_score     = rel_score,
                    has_submission_page = http.get("has_submission_page", False),
                    has_contact_page    = http.get("has_contact_page", False),
                    http_status         = http.get("http_status") or 0,
                    is_redirect         = http.get("is_redirect", False),
                    response_time_ms    = http.get("response_time_ms") or 9999,
                    is_parked           = http.get("is_parked", False),
                )

                # Write to DB
                self.db.update_assessment(opp["id"], {
                    "opr_score":           opr["opr_score"],
                    "opr_rank":            opr["opr_rank"],
                    "domain_created":      age["domain_created"],
                    "domain_age_years":    age["domain_age_years"],
                    "http_status":         http.get("http_status"),
                    "is_redirect":         int(http.get("is_redirect", False)),
                    "final_url":           http.get("final_url"),
                    "response_time_ms":    http.get("response_time_ms"),
                    "has_contact_page":    int(http.get("has_contact_page", False)),
                    "has_submission_page": int(http.get("has_submission_page", False)),
                    "is_parked":           int(http.get("is_parked", False)),
                    "relevance_score":     rel_score,
                    "total_score":         total,
                    "priority_tier":       tier,
                    "page_title":          http.get("page_title"),
                    "meta_description":    http.get("meta_description"),
                })

                logger.debug(
                    f"    OPR={opr['opr_score']:.1f} | Age={age['domain_age_years']:.1f}y | "
                    f"Rel={rel_score:.1f} | Score={total} | Tier={tier}"
                )
                assessed_count += 1

            except Exception as e:
                logger.error(f"  Assessment failed for {url}: {e}")
                continue

        self.db.log_run_end(run_id, assessed_count)
        logger.info(f"\nAssessment complete: {assessed_count} opportunities scored")
        return assessed_count


if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")
    import tempfile, os
    from pathlib import Path
    from storage.database import Database, Project, Opportunity
    from utils.helpers import url_hash

    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        tmp = Path(f.name)

    db = Database(db_path=tmp)
    db.connect()

    pid = db.create_project(Project(
        client_name="Test",
        project_url="https://test.com",
        primary_kw="seo agency",
        category="Marketing",
    ))

    # Insert a few test opportunities
    test_urls = [
        "https://example.com/write-for-us",
        "https://github.com/about",
    ]
    for url in test_urls:
        db.insert_opportunity(Opportunity(
            project_id=pid,
            url=url,
            domain=extract_domain(url),
            link_type="Guest Posts",
            url_hash=url_hash(url),
        ))

    project = db.get_project(pid)
    engine = AssessmentEngine(db, project, ["seo agency", "marketing", "Marketing"])
    count = engine.run()
    print(f"\nAssessed: {count}")

    results = db.get_opportunities(pid)
    for r in results:
        print(f"  {r['url'][:50]} | score={r['total_score']} | tier={r['priority_tier']}")

    db.close()
    os.unlink(tmp)
    print("Assessment engine test complete")
