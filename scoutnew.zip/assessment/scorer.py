"""
assessment/scorer.py — Composite scoring and tier assignment.

Takes raw metric values and computes a single 0-100 score
using the weighted formula from config.SCORE_WEIGHTS.

Also assigns a priority tier: A (80+), B (60-79), C (40-59), D (<40).
"""

from typing import Optional
from utils.logger import get_logger
import config

logger = get_logger(__name__)


def compute_score(
    opr_score:           float = 0.0,
    domain_age_years:    float = 0.0,
    relevance_score:     float = 0.0,
    has_submission_page: bool  = False,
    has_contact_page:    bool  = False,
    http_status:         int   = 0,
    is_redirect:         bool  = False,
    response_time_ms:    int   = 9999,
    is_parked:           bool  = False,
) -> tuple[float, str]:
    """
    Compute composite score and tier.

    Returns: (total_score: float 0-100, tier: str A/B/C/D)
    """
    weights = config.SCORE_WEIGHTS

    # ── Authority (max 30) ────────────────────────────────────────────────────
    # OPR 0-10 → 0-30 (linear)
    authority = min(10.0, float(opr_score or 0)) * 3.0

    # ── Age (max 20) ──────────────────────────────────────────────────────────
    age = float(domain_age_years or 0)
    if age >= 10:
        age_score = 20.0
    elif age >= 7:
        age_score = 17.0
    elif age >= 5:
        age_score = 14.0
    elif age >= 3:
        age_score = 10.0
    elif age >= 1:
        age_score = 6.0
    else:
        age_score = 0.0

    # ── Relevance (max 25) ────────────────────────────────────────────────────
    relevance = min(10.0, float(relevance_score or 0)) * 2.5

    # ── Opportunity (max 15) ─────────────────────────────────────────────────
    opportunity = 0.0
    if has_submission_page:
        opportunity += 10.0
    elif has_contact_page:
        opportunity += 5.0

    # ── Health (max 10) ───────────────────────────────────────────────────────
    health = 0.0
    if is_parked:
        health = 0.0  # parked = no health points
    else:
        if http_status == 200:
            health += 6.0
        elif http_status and 200 < http_status < 400:
            health += 3.0
        if not is_redirect:
            health += 2.0
        if response_time_ms and response_time_ms < 2000:
            health += 2.0
        elif response_time_ms and response_time_ms < 5000:
            health += 1.0

    total = round(authority + age_score + relevance + opportunity + health, 1)
    total = min(100.0, max(0.0, total))
    tier  = assign_tier(total)

    return total, tier


def assign_tier(score: float) -> str:
    """Map numeric score to A/B/C/D tier."""
    if score >= config.TIER_THRESHOLDS["A"]:
        return "A"
    elif score >= config.TIER_THRESHOLDS["B"]:
        return "B"
    elif score >= config.TIER_THRESHOLDS["C"]:
        return "C"
    else:
        return "D"


if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")

    # High-quality site
    s, t = compute_score(
        opr_score=7.5, domain_age_years=12, relevance_score=8.0,
        has_submission_page=True, http_status=200, is_redirect=False,
        response_time_ms=450,
    )
    print(f"High quality: score={s}, tier={t}")
    assert t == "A", f"Expected A, got {t}"

    # Medium site
    s2, t2 = compute_score(
        opr_score=3.5, domain_age_years=3, relevance_score=5.0,
        has_contact_page=True, http_status=200, is_redirect=True,
        response_time_ms=1800,
    )
    print(f"Medium: score={s2}, tier={t2}")
    assert t2 in ("B", "C"), f"Expected B or C, got {t2}"

    # Parked domain
    s3, t3 = compute_score(
        opr_score=0.5, domain_age_years=1, relevance_score=1.0,
        is_parked=True, http_status=200,
    )
    print(f"Parked: score={s3}, tier={t3}")
    assert t3 == "D", f"Expected D, got {t3}"

    print("Scorer tests PASSED")
