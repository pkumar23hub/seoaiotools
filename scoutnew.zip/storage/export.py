"""
storage/export.py — Export opportunities to CSV and Excel.

Excel output has 3 sheets:
  1. All Opportunities  — sorted by score DESC, conditional tier formatting
  2. Tier A             — top-priority only
  3. Summary Pivot      — count by link_type × tier

CSV output is a flat file of all columns, suitable for import into
outreach CRMs (Pitchbox, Respona, BuzzStream, etc.)
"""

import csv
from datetime import datetime
from pathlib import Path
from typing import Optional

from utils.logger import get_logger
import config

logger = get_logger(__name__)

# Columns to include in export (in order)
EXPORT_COLUMNS = [
    "id", "url", "domain", "link_type", "priority_tier", "total_score",
    "opr_score", "domain_age_years", "relevance_score",
    "has_submission_page", "has_contact_page",
    "http_status", "response_time_ms", "is_parked",
    "discovered_via", "status", "page_title", "notes",
    "discovered_at", "assessed_at",
]

TIER_COLOURS = {
    "A": "00C851",  # green
    "B": "FFD700",  # gold
    "C": "FF8800",  # orange
    "D": "CC0000",  # red
}


def export_csv(
    opportunities: list[dict],
    output_path: Path,
) -> Path:
    """
    Write opportunities to a CSV file.
    Returns the path written.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=EXPORT_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        for opp in opportunities:
            row = {col: opp.get(col, "") for col in EXPORT_COLUMNS}
            # Convert booleans
            for bool_col in ("has_submission_page", "has_contact_page", "is_parked"):
                if row[bool_col] in (0, 1, True, False):
                    row[bool_col] = "Yes" if row[bool_col] else "No"
            writer.writerow(row)

    logger.info(f"CSV exported: {output_path} ({len(opportunities)} rows)")
    return output_path


def export_excel(
    opportunities: list[dict],
    project: dict,
    output_path: Path,
) -> Path:
    """
    Write opportunities to an Excel file with 3 sheets.
    Returns the path written.
    """
    try:
        import openpyxl
        from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        logger.error("openpyxl not installed. Run: pip install openpyxl")
        return export_csv(opportunities, output_path.with_suffix(".csv"))

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    wb = openpyxl.Workbook()

    # ── Sheet 1: All Opportunities ────────────────────────────────────────────
    ws1 = wb.active
    ws1.title = "All Opportunities"
    _write_sheet(ws1, opportunities, project)

    # ── Sheet 2: Tier A Only ──────────────────────────────────────────────────
    tier_a = [o for o in opportunities if o.get("priority_tier") == "A"]
    ws2 = wb.create_sheet("Tier A Priority")
    _write_sheet(ws2, tier_a, project)

    # ── Sheet 3: Summary Pivot ────────────────────────────────────────────────
    ws3 = wb.create_sheet("Summary by Type")
    _write_pivot(ws3, opportunities)

    wb.save(output_path)
    logger.info(f"Excel exported: {output_path} ({len(opportunities)} rows)")
    return output_path


def _write_sheet(ws, opportunities: list[dict], project: dict):
    """Write a full opportunity list to a worksheet with formatting."""
    from openpyxl.styles import PatternFill, Font, Alignment
    from openpyxl.utils import get_column_letter

    # Header row
    headers = [c.replace("_", " ").title() for c in EXPORT_COLUMNS]
    ws.append(headers)

    # Style header
    header_fill = PatternFill("solid", fgColor="1F3864")
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = Font(color="FFFFFF", bold=True, size=10)
        cell.alignment = Alignment(horizontal="center")

    # Data rows
    tier_fills = {t: PatternFill("solid", fgColor=c) for t, c in TIER_COLOURS.items()}

    for opp in opportunities:
        row = []
        for col in EXPORT_COLUMNS:
            val = opp.get(col, "")
            if col in ("has_submission_page", "has_contact_page", "is_parked"):
                val = "Yes" if val else "No"
            row.append(val)
        ws.append(row)

        # Colour entire row by tier
        tier = opp.get("priority_tier", "D") or "D"
        fill = tier_fills.get(tier, tier_fills["D"])
        # Only colour the tier cell (column 5) for cleaner look
        tier_cell = ws.cell(row=ws.max_row, column=5)
        tier_cell.fill = fill
        tier_cell.font = Font(bold=True)

    # Column widths
    col_widths = {"url": 50, "domain": 30, "link_type": 20, "page_title": 40}
    for i, col in enumerate(EXPORT_COLUMNS, 1):
        width = col_widths.get(col, 14)
        ws.column_dimensions[get_column_letter(i)].width = width

    # Freeze top row
    ws.freeze_panes = "A2"


def _write_pivot(ws, opportunities: list[dict]):
    """Write a summary pivot: link_type × tier counts."""
    from openpyxl.styles import PatternFill, Font, Alignment

    # Build pivot data
    from collections import defaultdict
    pivot = defaultdict(lambda: {"A": 0, "B": 0, "C": 0, "D": 0, "Total": 0})
    for opp in opportunities:
        lt = opp.get("link_type", "Unknown")
        tier = opp.get("priority_tier", "D") or "D"
        pivot[lt][tier] += 1
        pivot[lt]["Total"] += 1

    # Header
    ws.append(["Link Type", "Tier A", "Tier B", "Tier C", "Tier D", "Total"])
    header_fill = PatternFill("solid", fgColor="1F3864")
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = Font(color="FFFFFF", bold=True)

    for lt, counts in sorted(pivot.items(), key=lambda x: -x[1]["Total"]):
        ws.append([lt, counts["A"], counts["B"], counts["C"], counts["D"], counts["Total"]])

    # Totals row
    total_row = ["TOTAL",
                 sum(v["A"] for v in pivot.values()),
                 sum(v["B"] for v in pivot.values()),
                 sum(v["C"] for v in pivot.values()),
                 sum(v["D"] for v in pivot.values()),
                 sum(v["Total"] for v in pivot.values())]
    ws.append(total_row)
    for cell in ws[ws.max_row]:
        cell.font = Font(bold=True)

    for col in ["A", "B", "C", "D", "E", "F"]:
        ws.column_dimensions[col].width = 16
    ws.freeze_panes = "A2"


def generate_filename(project: dict, suffix: str) -> str:
    """Generate a timestamped filename for exports."""
    from utils.helpers import slugify
    slug = slugify(project.get("client_name", "project"))
    ts = datetime.now().strftime("%Y%m%d_%H%M")
    return f"scout_{slug}_{ts}{suffix}"


if __name__ == "__main__":
    import sys, tempfile, os
    sys.path.insert(0, ".")

    # Mock data test
    opps = [
        {"id": 1, "url": "https://example.com/write-for-us", "domain": "example.com",
         "link_type": "Guest Posts", "priority_tier": "A", "total_score": 85.0,
         "opr_score": 7.0, "domain_age_years": 10.0, "relevance_score": 8.0,
         "has_submission_page": True, "has_contact_page": True, "http_status": 200,
         "response_time_ms": 450, "is_parked": False, "discovered_via": "serp_api",
         "status": "assessed", "page_title": "Write for Us", "notes": ""},
        {"id": 2, "url": "https://site2.com/resources", "domain": "site2.com",
         "link_type": "Niche Edits", "priority_tier": "B", "total_score": 65.0,
         "opr_score": 4.0, "domain_age_years": 5.0, "relevance_score": 6.0,
         "has_submission_page": False, "has_contact_page": True, "http_status": 200,
         "response_time_ms": 800, "is_parked": False, "discovered_via": "common_crawl",
         "status": "assessed", "page_title": "Resources", "notes": ""},
    ]
    project = {"client_name": "Test Client", "id": 1}

    with tempfile.TemporaryDirectory() as tmpdir:
        csv_path = Path(tmpdir) / "test.csv"
        xls_path = Path(tmpdir) / "test.xlsx"

        export_csv(opps, csv_path)
        assert csv_path.exists()
        with open(csv_path) as f:
            lines = f.readlines()
        assert len(lines) == 3  # header + 2 rows

        export_excel(opps, project, xls_path)
        assert xls_path.exists()

    print("Export tests PASSED")
