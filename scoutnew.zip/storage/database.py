"""
storage/database.py — SQLite interface for Scout.

Single entry point for all DB operations. Every other module calls
functions here; nothing else touches sqlite3 directly.

Tables:
  projects       — one row per client/campaign
  opportunities  — discovered + assessed URLs
  run_log        — timestamped record of every engine run
  serp_budget    — tracks monthly SerpAPI usage
"""

import sqlite3
import json
from datetime import datetime, date
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, field, asdict

from utils.logger import get_logger

logger = get_logger(__name__)


# ── Data Models ───────────────────────────────────────────────────────────────

@dataclass
class Project:
    client_name:  str
    project_url:  str
    primary_kw:   str
    secondary_kw1: str = ""
    secondary_kw2: str = ""
    secondary_kw3: str = ""
    category:     str = ""
    services:     str = ""
    location:     str = ""
    competitor1:  str = ""
    competitor2:  str = ""
    id:           Optional[int] = None
    created_at:   Optional[str] = None


@dataclass
class Opportunity:
    project_id:       int
    url:              str
    domain:           str
    link_type:        str
    url_hash:         str
    discovered_via:   str = ""
    # assessment fields — all optional until assessed
    opr_score:        Optional[float] = None
    opr_rank:         Optional[int]   = None
    domain_age_years: Optional[float] = None
    domain_created:   Optional[str]   = None
    wayback_first_seen: Optional[str] = None
    http_status:      Optional[int]   = None
    is_redirect:      Optional[bool]  = None
    final_url:        Optional[str]   = None
    response_time_ms: Optional[int]   = None
    has_contact_page: Optional[bool]  = None
    has_submission_page: Optional[bool] = None
    is_parked:        Optional[bool]  = None
    relevance_score:  Optional[float] = None
    total_score:      Optional[float] = None
    priority_tier:    Optional[str]   = None
    page_title:       Optional[str]   = None
    meta_description: Optional[str]   = None
    status:           str = "discovered"
    notes:            str = ""
    id:               Optional[int]   = None
    discovered_at:    Optional[str]   = None
    assessed_at:      Optional[str]   = None
    submitted_at:     Optional[str]   = None


# ── Connection Manager ────────────────────────────────────────────────────────

class Database:
    """
    Thin SQLite wrapper. One instance per project run.

    Usage:
        db = Database(project_slug="acme_legal")
        db.connect()
        db.create_project(...)
        db.close()

    Or as context manager:
        with Database("acme_legal") as db:
            ...
    """

    def __init__(self, db_path: Optional[Path] = None, project_slug: str = "default"):
        if db_path:
            self.path = db_path
        else:
            try:
                from config import DB_DIR
            except ImportError:
                DB_DIR = Path(__file__).parent.parent / "databases"
                DB_DIR.mkdir(parents=True, exist_ok=True)
            self.path = DB_DIR / f"scout_{project_slug}.db"
        self._conn: Optional[sqlite3.Connection] = None

    def connect(self) -> "Database":
        self._conn = sqlite3.connect(
            self.path,
            detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES,
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._create_tables()
        logger.debug(f"DB connected: {self.path}")
        return self

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None

    def __enter__(self):
        return self.connect()

    def __exit__(self, *_):
        self.close()

    @property
    def conn(self) -> sqlite3.Connection:
        if not self._conn:
            raise RuntimeError("Database not connected. Call .connect() first.")
        return self._conn

    # ── Schema Creation ───────────────────────────────────────────────────────

    def _create_tables(self):
        self.conn.executescript("""
        CREATE TABLE IF NOT EXISTS projects (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            client_name   TEXT NOT NULL,
            project_url   TEXT NOT NULL,
            primary_kw    TEXT,
            secondary_kw1 TEXT,
            secondary_kw2 TEXT,
            secondary_kw3 TEXT,
            category      TEXT,
            services      TEXT,
            location      TEXT,
            competitor1   TEXT,
            competitor2   TEXT,
            created_at    TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS opportunities (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id          INTEGER NOT NULL REFERENCES projects(id),
            url                 TEXT NOT NULL,
            domain              TEXT NOT NULL,
            link_type           TEXT NOT NULL,
            url_hash            TEXT UNIQUE NOT NULL,
            discovered_via      TEXT DEFAULT '',
            opr_score           REAL,
            opr_rank            INTEGER,
            domain_age_years    REAL,
            domain_created      TEXT,
            wayback_first_seen  TEXT,
            http_status         INTEGER,
            is_redirect         INTEGER,
            final_url           TEXT,
            response_time_ms    INTEGER,
            has_contact_page    INTEGER,
            has_submission_page INTEGER,
            is_parked           INTEGER,
            relevance_score     REAL,
            total_score         REAL,
            priority_tier       TEXT,
            page_title          TEXT,
            meta_description    TEXT,
            status              TEXT DEFAULT 'discovered',
            notes               TEXT DEFAULT '',
            discovered_at       TEXT DEFAULT (datetime('now')),
            assessed_at         TEXT,
            submitted_at        TEXT
        );

        CREATE INDEX IF NOT EXISTS idx_opp_project   ON opportunities(project_id);
        CREATE INDEX IF NOT EXISTS idx_opp_link_type ON opportunities(link_type);
        CREATE INDEX IF NOT EXISTS idx_opp_status    ON opportunities(status);
        CREATE INDEX IF NOT EXISTS idx_opp_tier      ON opportunities(priority_tier);
        CREATE INDEX IF NOT EXISTS idx_opp_domain    ON opportunities(domain);

        CREATE TABLE IF NOT EXISTS run_log (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id   INTEGER REFERENCES projects(id),
            run_type     TEXT,
            started_at   TEXT,
            ended_at     TEXT,
            count_found  INTEGER DEFAULT 0,
            sources_used TEXT,
            notes        TEXT
        );

        CREATE TABLE IF NOT EXISTS serp_budget (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            year_month  TEXT NOT NULL,
            calls_used  INTEGER DEFAULT 0,
            UNIQUE(year_month)
        );
        """)
        self.conn.commit()
        logger.debug("Schema verified/created")

    # ── Project CRUD ──────────────────────────────────────────────────────────

    def create_project(self, p: Project) -> int:
        cur = self.conn.execute("""
            INSERT INTO projects
            (client_name, project_url, primary_kw, secondary_kw1, secondary_kw2,
             secondary_kw3, category, services, location, competitor1, competitor2)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """, (p.client_name, p.project_url, p.primary_kw, p.secondary_kw1,
              p.secondary_kw2, p.secondary_kw3, p.category, p.services,
              p.location, p.competitor1, p.competitor2))
        self.conn.commit()
        pid = cur.lastrowid
        logger.info(f"Created project #{pid}: {p.client_name}")
        return pid

    def get_project(self, project_id: int) -> Optional[dict]:
        row = self.conn.execute(
            "SELECT * FROM projects WHERE id=?", (project_id,)
        ).fetchone()
        return dict(row) if row else None

    def list_projects(self) -> list[dict]:
        rows = self.conn.execute(
            "SELECT id, client_name, project_url, created_at FROM projects ORDER BY id DESC"
        ).fetchall()
        return [dict(r) for r in rows]

    # ── Opportunity CRUD ──────────────────────────────────────────────────────

    def insert_opportunity(self, opp: Opportunity) -> Optional[int]:
        """
        Insert a new opportunity. Returns row id, or None if URL already exists
        (dedup via url_hash UNIQUE constraint).
        """
        try:
            cur = self.conn.execute("""
                INSERT INTO opportunities
                (project_id, url, domain, link_type, url_hash, discovered_via)
                VALUES (?,?,?,?,?,?)
            """, (opp.project_id, opp.url, opp.domain, opp.link_type,
                  opp.url_hash, opp.discovered_via))
            self.conn.commit()
            return cur.lastrowid
        except sqlite3.IntegrityError:
            # Duplicate url_hash — silently skip
            return None

    def bulk_insert_opportunities(self, opps: list[Opportunity]) -> tuple[int, int]:
        """
        Insert a batch. Returns (inserted, skipped) counts.
        """
        inserted = skipped = 0
        for opp in opps:
            result = self.insert_opportunity(opp)
            if result:
                inserted += 1
            else:
                skipped += 1
        return inserted, skipped

    def get_unassessed(self, project_id: int, limit: int = 0) -> list[dict]:
        """Return all opportunities with status='discovered' (not yet assessed)."""
        q = """
            SELECT * FROM opportunities
            WHERE project_id=? AND status='discovered'
            ORDER BY id ASC
        """
        params = [project_id]
        if limit > 0:
            q += " LIMIT ?"
            params.append(limit)
        return [dict(r) for r in self.conn.execute(q, params).fetchall()]

    def update_assessment(self, opp_id: int, data: dict):
        """
        Update assessment fields on an opportunity.
        data: dict of column→value pairs to set.
        """
        data["assessed_at"] = datetime.now().isoformat()
        data["status"] = "assessed"
        cols = ", ".join(f"{k}=?" for k in data)
        vals = list(data.values()) + [opp_id]
        self.conn.execute(f"UPDATE opportunities SET {cols} WHERE id=?", vals)
        self.conn.commit()

    def update_status(self, opp_id: int, status: str, notes: str = ""):
        """Update workflow status for an opportunity."""
        self.conn.execute(
            "UPDATE opportunities SET status=?, notes=? WHERE id=?",
            (status, notes, opp_id)
        )
        if status == "submitted":
            self.conn.execute(
                "UPDATE opportunities SET submitted_at=? WHERE id=?",
                (datetime.now().isoformat(), opp_id)
            )
        self.conn.commit()

    def get_opportunities(
        self,
        project_id: int,
        tier: Optional[str] = None,
        link_type: Optional[str] = None,
        status: Optional[str] = None,
    ) -> list[dict]:
        """Flexible query with optional filters."""
        q = "SELECT * FROM opportunities WHERE project_id=?"
        params: list = [project_id]
        if tier:
            q += " AND priority_tier=?"
            params.append(tier)
        if link_type:
            q += " AND link_type=?"
            params.append(link_type)
        if status:
            q += " AND status=?"
            params.append(status)
        q += " ORDER BY COALESCE(total_score, 0) DESC"
        return [dict(r) for r in self.conn.execute(q, params).fetchall()]

    def count_by_link_type(self, project_id: int) -> list[dict]:
        rows = self.conn.execute("""
            SELECT link_type,
                   COUNT(*) as total,
                   SUM(CASE WHEN status='assessed' THEN 1 ELSE 0 END) as assessed,
                   SUM(CASE WHEN priority_tier='A' THEN 1 ELSE 0 END) as tier_a,
                   SUM(CASE WHEN priority_tier='B' THEN 1 ELSE 0 END) as tier_b
            FROM opportunities
            WHERE project_id=?
            GROUP BY link_type
            ORDER BY total DESC
        """, (project_id,)).fetchall()
        return [dict(r) for r in rows]

    # ── Run Log ───────────────────────────────────────────────────────────────

    def log_run_start(self, project_id: int, run_type: str, sources: list[str]) -> int:
        cur = self.conn.execute("""
            INSERT INTO run_log (project_id, run_type, started_at, sources_used)
            VALUES (?,?,?,?)
        """, (project_id, run_type, datetime.now().isoformat(), json.dumps(sources)))
        self.conn.commit()
        return cur.lastrowid

    def log_run_end(self, run_id: int, count: int, notes: str = ""):
        self.conn.execute("""
            UPDATE run_log SET ended_at=?, count_found=?, notes=? WHERE id=?
        """, (datetime.now().isoformat(), count, notes, run_id))
        self.conn.commit()

    # ── SerpAPI Budget ────────────────────────────────────────────────────────

    def get_serp_usage(self) -> int:
        """Return calls used in current month."""
        ym = datetime.now().strftime("%Y-%m")
        row = self.conn.execute(
            "SELECT calls_used FROM serp_budget WHERE year_month=?", (ym,)
        ).fetchone()
        return row["calls_used"] if row else 0

    def increment_serp_usage(self, count: int = 1):
        ym = datetime.now().strftime("%Y-%m")
        self.conn.execute("""
            INSERT INTO serp_budget (year_month, calls_used)
            VALUES (?, ?)
            ON CONFLICT(year_month) DO UPDATE SET calls_used = calls_used + ?
        """, (ym, count, count))
        self.conn.commit()

    # ── Stats ─────────────────────────────────────────────────────────────────

    def summary_stats(self, project_id: int) -> dict:
        row = self.conn.execute("""
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN status='assessed' THEN 1 ELSE 0 END) as assessed,
                SUM(CASE WHEN priority_tier='A' THEN 1 ELSE 0 END) as tier_a,
                SUM(CASE WHEN priority_tier='B' THEN 1 ELSE 0 END) as tier_b,
                SUM(CASE WHEN priority_tier='C' THEN 1 ELSE 0 END) as tier_c,
                SUM(CASE WHEN priority_tier='D' THEN 1 ELSE 0 END) as tier_d,
                ROUND(AVG(total_score), 1) as avg_score
            FROM opportunities WHERE project_id=?
        """, (project_id,)).fetchone()
        return dict(row) if row else {}


if __name__ == "__main__":
    import sys, tempfile, os
    sys.path.insert(0, str(Path(__file__).parent.parent))

    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        tmp = Path(f.name)

    db = Database(db_path=tmp)
    db.connect()

    # Test project creation
    pid = db.create_project(Project(
        client_name="Test Client",
        project_url="https://test.com",
        primary_kw="test keyword",
    ))
    assert pid == 1

    # Test opportunity insert + dedup
    from utils.helpers import url_hash, extract_domain
    opp = Opportunity(
        project_id=pid,
        url="https://example.com/write-for-us",
        domain=extract_domain("https://example.com"),
        link_type="Guest Posts",
        url_hash=url_hash("https://example.com/write-for-us"),
        discovered_via="serp_api",
    )
    id1 = db.insert_opportunity(opp)
    id2 = db.insert_opportunity(opp)  # duplicate
    assert id1 is not None
    assert id2 is None  # deduped

    # Test bulk insert
    opps = [
        Opportunity(
            project_id=pid,
            url=f"https://site{i}.com/page",
            domain=f"site{i}.com",
            link_type="Directories",
            url_hash=url_hash(f"https://site{i}.com/page"),
        )
        for i in range(5)
    ]
    ins, skip = db.bulk_insert_opportunities(opps)
    assert ins == 5 and skip == 0

    # Test assessment update
    unassessed = db.get_unassessed(pid)
    assert len(unassessed) == 6
    db.update_assessment(unassessed[0]["id"], {"opr_score": 4.5, "total_score": 72.0, "priority_tier": "B"})

    stats = db.summary_stats(pid)
    assert stats["total"] == 6

    db.close()
    os.unlink(tmp)
    print("All database tests passed ✓")
