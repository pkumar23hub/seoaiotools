"""
inputs.py — Interactive CLI input collection for Scout.

Gathers project details from the user, validates them, and returns a
populated Project dataclass ready for DB insertion.

Also handles --project-id flag for resuming an existing project.
"""

from typing import Optional
from storage.database import Project
from utils.helpers import slugify, extract_domain
from utils.logger import get_logger

logger = get_logger(__name__)


def collect_project_inputs() -> Project:
    """
    Interactive prompt flow to collect all project fields.
    Returns a Project dataclass (not yet saved to DB).
    """
    print()
    print("=" * 60)
    print("  SCOUT — New Project Setup")
    print("=" * 60)
    print()

    client_name = _prompt("Client / Company Name", required=True)
    project_url = _prompt_url("Project URL (e.g. https://acmelegal.com)", required=True)
    primary_kw  = _prompt("Primary Keyword (e.g. personal injury lawyer)", required=True)

    print("\n  [ Secondary Keywords — press Enter to skip any ]")
    sk1 = _prompt("  Secondary Keyword 1", required=False)
    sk2 = _prompt("  Secondary Keyword 2", required=False)
    sk3 = _prompt("  Secondary Keyword 3", required=False)

    print()
    category = _prompt("Industry / Category (e.g. Legal, Healthcare, SaaS)", required=False)
    services = _prompt("Services (comma-separated, e.g. Personal Injury, Car Accidents)", required=False)
    location = _prompt("Location / Target Region (e.g. Houston TX, USA, Global)", required=False)

    print("\n  [ Competitor URLs — optional, enables backlink gap discovery ]")
    comp1 = _prompt_url("  Competitor URL 1", required=False)
    comp2 = _prompt_url("  Competitor URL 2", required=False)

    print()
    project = Project(
        client_name   = client_name,
        project_url   = project_url,
        primary_kw    = primary_kw,
        secondary_kw1 = sk1,
        secondary_kw2 = sk2,
        secondary_kw3 = sk3,
        category      = category,
        services      = services,
        location      = location,
        competitor1   = comp1,
        competitor2   = comp2,
    )

    _confirm_inputs(project)
    return project


def _prompt(label: str, required: bool = True, default: str = "") -> str:
    while True:
        val = input(f"  {label}: ").strip()
        if val:
            return val
        if not required:
            return default
        print(f"  ⚠  This field is required.")


def _prompt_url(label: str, required: bool = True) -> str:
    while True:
        val = input(f"  {label}: ").strip()
        if not val:
            if not required:
                return ""
            print("  ⚠  URL is required.")
            continue
        # Auto-add https:// if missing
        if not val.startswith(("http://", "https://")):
            val = "https://" + val
        # Basic validation
        if "." in val:
            return val
        print("  ⚠  Please enter a valid URL (e.g. https://example.com)")


def _confirm_inputs(p: Project):
    print()
    print("─" * 60)
    print("  Review your project details:")
    print("─" * 60)
    print(f"  Client Name   : {p.client_name}")
    print(f"  Project URL   : {p.project_url}")
    print(f"  Primary KW    : {p.primary_kw}")
    print(f"  Secondary KWs : {', '.join(filter(None, [p.secondary_kw1, p.secondary_kw2, p.secondary_kw3]))}")
    print(f"  Category      : {p.category or '—'}")
    print(f"  Services      : {p.services or '—'}")
    print(f"  Location      : {p.location or '—'}")
    if p.competitor1:
        print(f"  Competitor 1  : {p.competitor1}")
    if p.competitor2:
        print(f"  Competitor 2  : {p.competitor2}")
    print("─" * 60)
    confirm = input("  Proceed? [Y/n]: ").strip().lower()
    if confirm == "n":
        print("\n  Starting over...\n")
        raise KeyboardInterrupt("User restarted input")


def project_to_slug(p: Project) -> str:
    """Convert project into a safe DB filename slug."""
    return slugify(f"{p.client_name}")


def get_keyword_set(p: Project) -> list[str]:
    """
    Return expanded keyword list from a Project.
    Delegates to helpers.build_keyword_set.
    """
    from utils.helpers import build_keyword_set
    return build_keyword_set(
        primary    = p.primary_kw,
        secondary  = [p.secondary_kw1, p.secondary_kw2, p.secondary_kw3],
        niche      = p.category,
        location   = p.location,
    )


if __name__ == "__main__":
    # Non-interactive test — simulate inputs
    import unittest.mock as mock

    responses = iter([
        "Test Client",         # client_name
        "https://test.com",    # project_url
        "seo services",        # primary_kw
        "link building",       # sk1
        "",                    # sk2
        "",                    # sk3
        "Marketing",           # category
        "SEO, PPC",            # services
        "London",              # location
        "",                    # competitor1
        "",                    # competitor2
        "Y",                   # confirm
    ])
    with mock.patch("builtins.input", lambda _: next(responses)):
        p = collect_project_inputs()

    assert p.client_name == "Test Client"
    assert p.primary_kw == "seo services"
    assert p.secondary_kw1 == "link building"
    slug = project_to_slug(p)
    assert slug == "test_client"
    kws = get_keyword_set(p)
    assert "seo services" in kws
    assert "London" in kws
    print("Input collection tests passed ✓")
