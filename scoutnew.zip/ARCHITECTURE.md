# Scout — Technical Architecture

## Dependency Graph

Modules must always be imported in this order (lower layers have no upward deps):

```
Layer 0 — Foundation
  config.py          ← reads .env, defines all constants
  utils/logger.py    ← no deps (stdlib only)
  utils/helpers.py   ← no deps (stdlib only)
  storage/database.py ← imports config, utils
  inputs.py          ← imports storage, utils

Layer 1 — Discovery Sources
  discovery/sources/common_crawl.py  ← imports config, utils
  discovery/sources/serp_api.py      ← imports config, utils, storage (budget)
  discovery/sources/github_search.py ← imports config, utils
  discovery/sources/reddit_api.py    ← imports config, utils

Layer 2 — Discovery Engine
  discovery/footprints.py  ← no imports (pure data)
  discovery/engine.py      ← imports all Layer 1 sources + footprints + storage

Layer 3 — Assessment Engine
  assessment/metrics/open_pagerank.py  ← imports config, utils
  assessment/metrics/domain_age.py     ← imports utils
  assessment/metrics/http_check.py     ← imports config, utils
  assessment/metrics/relevance.py      ← imports utils
  assessment/scorer.py                 ← imports config only
  assessment/engine.py                 ← imports all metrics + scorer + storage

Layer 4 — Output
  storage/export.py    ← imports config, utils
  reports/reporter.py  ← imports utils (rich)
  main.py              ← imports everything via click commands
```

## Module Interfaces

### Database (storage/database.py)

All data access goes through the `Database` class. No module touches sqlite3 directly.

Key methods:
- `create_project(Project) → int` — returns project_id
- `insert_opportunity(Opportunity) → int|None` — None = duplicate (url_hash UNIQUE)
- `bulk_insert_opportunities(list) → (inserted, skipped)`
- `get_unassessed(project_id, limit) → list[dict]`
- `update_assessment(opp_id, dict)` — updates scores + sets status='assessed'
- `update_status(opp_id, status, notes)` — workflow tracking
- `get_opportunities(project_id, tier, link_type, status) → list[dict]`
- `summary_stats(project_id) → dict`

### Discovery Sources

Each source module exposes one main function:

```python
common_crawl.discover_by_patterns(patterns, limit_per_pattern) → list[dict]
  # dict keys: url, domain, url_hash, cc_pattern, timestamp

serp_api.batch_search(queries, db) → list[dict]
  # dict keys: url, title, snippet, domain, url_hash

github_search.discover(queries) → list[dict]
  # dict keys: url, domain, url_hash, source_repo, github_query

reddit_api.discover(queries, niche, extra_subreddits) → list[dict]
  # dict keys: url, domain, url_hash, source_subreddit, post_title
```

### Assessment Metrics

Each metric module returns a plain dict:

```python
open_pagerank.get_pagerank_bulk(domains)
  → {domain: {opr_score: float, opr_rank: int}}

domain_age.get_domain_age(domain)
  → {domain_created: str|None, domain_age_years: float}

http_check.check_url(url)
  → {http_status, is_redirect, final_url, response_time_ms,
     has_contact_page, has_submission_page, is_parked,
     page_title, meta_description}

relevance.score_relevance(url, keywords, page_title, meta_description, niche)
  → float (0.0-10.0)
```

### Scorer

```python
scorer.compute_score(**metric_kwargs) → (total_score: float, tier: str)
scorer.assign_tier(score) → "A"|"B"|"C"|"D"
```

## Deduplication Strategy

Two levels:

1. **In-run dedup** — `DiscoveryEngine._seen_hashes` set. Before inserting any URL,
   its MD5 hash is checked against this set. Same URL discovered from two different
   sources in the same run is only inserted once.

2. **Cross-run dedup** — On `DiscoveryEngine.__init__`, all existing `url_hash`
   values for the project are loaded into `_seen_hashes`. A URL discovered in a
   previous run is never re-inserted.

3. **DB constraint** — `url_hash` column has `UNIQUE` constraint.
   `insert_opportunity` catches `sqlite3.IntegrityError` and returns `None`.
   This is the final safety net.

## Rate Limiting

Centralised in `config.RATE_LIMITS` dict. Each source calls `utils.helpers.sleep_rate(source_name)` which reads the delay from config and sleeps.

Adjustable per-source without touching source code:

```python
# config.py
RATE_LIMITS = {
    "serp_api":      2.0,   # seconds between SerpAPI calls
    "common_crawl":  2.0,
    "github":        2.5,
    "reddit":        1.5,
    "open_pagerank": 0.05,
    "http_check":    1.0,
    "whois":         0.8,
    "wayback":       0.5,
}
```

## SerpAPI Budget Guard

SerpAPI has a 100 searches/month free limit. Two protection layers:

1. `config.SERPAPI_MONTHLY_BUDGET = 95` — hard cap before fallback
2. `db.get_serp_usage()` / `db.increment_serp_usage()` — monthly counter
   stored in `serp_budget` table keyed by `YYYY-MM`
3. `serp_api.search()` checks budget before every call and returns `[]` if exceeded

## Adding a New Source

1. Create `discovery/sources/new_source.py` with a `discover(queries) -> list[dict]` function
2. Each result dict must include: `url`, `domain`, `url_hash`, `source`
3. Import in `discovery/engine.py` and add a new `if "newsource" in sources:` block
4. Add `"newsource"` to the CLI `--sources` choice in `main.py`

## Adding a New Link Type

1. Add a class to `discovery/footprints.py` with 4 static methods:
   `serp_queries()`, `cdx_patterns()`, `github_queries()`, `reddit_queries()`
2. Register in `LINK_TYPE_CLASSES` dict at bottom of `footprints.py`
3. Add name to `config.LINK_TYPES` list
4. No other changes needed — engine iterates `LINK_TYPE_CLASSES` dynamically

## Adding a New Assessment Metric

1. Create `assessment/metrics/new_metric.py` returning a dict
2. Import in `assessment/engine.py` and call it per-URL
3. Add result fields to `db.update_assessment()` call
4. If it affects the score, add a parameter to `assessment/scorer.compute_score()`

## Database Schema Summary

```
projects        — one row per client/campaign
opportunities   — all discovered + assessed URLs (url_hash UNIQUE)
run_log         — every engine run timestamped with counts
serp_budget     — monthly SerpAPI call counter (YYYY-MM keyed)
```

DB files: `scout/databases/scout_{client_slug}.db`
One DB per client project. Multiple projects supported.
