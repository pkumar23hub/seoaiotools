@echo off
setlocal enabledelayedexpansion

:: ============================================================
:: SCOUT - Zero-Cost Link Opportunity Pipeline
:: Self-contained Windows Installer v1.0.1
:: ============================================================
:: Usage:
::   SETUP.bat                  - full install with API key prompts
::   SETUP.bat --skip-keys      - install without API key setup
::   SETUP.bat --repair         - delete venv and reinstall
::   SETUP.bat --debug          - verbose pip output
::   SETUP.bat --help           - show this help
:: ============================================================

:: --- Parse flags ---
set "FLAG_SKIP_KEYS=0"
set "FLAG_REPAIR=0"
set "FLAG_DEBUG=0"
set "FLAG_HELP=0"

:parse_args
if "%~1"=="" goto args_done
if /i "%~1"=="--skip-keys" set "FLAG_SKIP_KEYS=1"
if /i "%~1"=="--repair"    set "FLAG_REPAIR=1"
if /i "%~1"=="--debug"     set "FLAG_DEBUG=1"
if /i "%~1"=="--help"      set "FLAG_HELP=1"
shift
goto parse_args
:args_done

if "%FLAG_HELP%"=="1" (
    echo.
    echo Scout Installer
    echo ===============
    echo Usage:
    echo   SETUP.bat                  - full install
    echo   SETUP.bat --skip-keys      - skip API key prompts
    echo   SETUP.bat --repair         - rebuild virtual environment
    echo   SETUP.bat --debug          - verbose pip output
    echo   SETUP.bat --help           - show this help
    echo.
    goto :eof
)

:: --- Setup ---
set "SCOUT_DIR=%~dp0"
if "%SCOUT_DIR:~-1%"=="\" set "SCOUT_DIR=%SCOUT_DIR:~0,-1%"
set "VENV_DIR=%SCOUT_DIR%\venv"
set "LOG_FILE=%SCOUT_DIR%\setup_log.txt"
set "ENV_FILE=%SCOUT_DIR%\.env"
set "ERROR_COUNT=0"

echo. > "%LOG_FILE%"
call :log "Scout Installer started: %DATE% %TIME%"
call :log "Scout directory: %SCOUT_DIR%"
call :log "Flags: skip-keys=%FLAG_SKIP_KEYS% repair=%FLAG_REPAIR% debug=%FLAG_DEBUG%"

echo.
echo ============================================================
echo   Scout - Zero-Cost Link Opportunity Pipeline
echo   Installer v1.0.1
echo ============================================================
echo.
echo Install directory: %SCOUT_DIR%
echo Log file: %LOG_FILE%
echo.

:: ============================================================
:: STEP 1 - Find Python
:: ============================================================
echo [Step 1/7] Checking Python...
call :log "--- Step 1: Python check ---"

set "PY_CMD="
for %%C in (python python3 py) do (
    if "!PY_CMD!"=="" (
        %%C --version >nul 2>&1
        if !errorlevel!==0 set "PY_CMD=%%C"
    )
)

if "%PY_CMD%"=="" (
    echo.
    echo  [ERROR] Python not found.
    echo.
    echo  Please install Python 3.9 or later from:
    echo    https://python.org/downloads
    echo.
    echo  Make sure to check "Add Python to PATH" during install.
    echo  After installing, close and reopen this window, then run SETUP.bat again.
    echo.
    call :log "ERROR: Python not found"
    set /a ERROR_COUNT+=1
    goto :install_failed
)

call :log "Python command: %PY_CMD%"

:: Get version and check >= 3.9
for /f "tokens=2" %%V in ('%PY_CMD% --version 2^>^&1') do set "PY_VER=%%V"
call :log "Python version: %PY_VER%"

for /f "tokens=1,2 delims=." %%A in ("%PY_VER%") do (
    set "PY_MAJOR=%%A"
    set "PY_MINOR=%%B"
)

if %PY_MAJOR% LSS 3 (
    echo  [ERROR] Python %PY_VER% is too old. Scout requires Python 3.9+.
    echo  Download: https://python.org/downloads
    call :log "ERROR: Python too old: %PY_VER%"
    set /a ERROR_COUNT+=1
    goto :install_failed
)
if %PY_MAJOR%==3 if %PY_MINOR% LSS 9 (
    echo  [ERROR] Python %PY_VER% is too old. Scout requires Python 3.9+.
    echo  Download: https://python.org/downloads
    call :log "ERROR: Python too old: %PY_VER%"
    set /a ERROR_COUNT+=1
    goto :install_failed
)

echo  [OK] Python %PY_VER% found (%PY_CMD%)
call :log "Python OK: %PY_VER%"

:: ============================================================
:: STEP 2 - Check pip
:: ============================================================
echo.
echo [Step 2/7] Checking pip...
call :log "--- Step 2: pip check ---"

%PY_CMD% -m pip --version >nul 2>&1
if errorlevel 1 (
    echo  pip not found, attempting to install via ensurepip...
    call :log "pip missing, trying ensurepip"
    %PY_CMD% -m ensurepip --upgrade >"%LOG_FILE%.pip_bootstrap.txt" 2>&1
    if errorlevel 1 (
        echo  [ERROR] Could not install pip. See %LOG_FILE%
        call :log "ERROR: ensurepip failed"
        set /a ERROR_COUNT+=1
        goto :install_failed
    )
)

echo  [OK] pip available
call :log "pip OK"

:: ============================================================
:: STEP 3 - Virtual environment
:: ============================================================
echo.
echo [Step 3/7] Setting up virtual environment...
call :log "--- Step 3: venv ---"

if "%FLAG_REPAIR%"=="1" (
    if exist "%VENV_DIR%" (
        echo  --repair flag set: removing existing venv...
        call :log "Repair: removing %VENV_DIR%"
        rmdir /s /q "%VENV_DIR%"
    )
)

if not exist "%VENV_DIR%" (
    echo  Creating virtual environment...
    call :log "Creating venv at %VENV_DIR%"
    %PY_CMD% -m venv "%VENV_DIR%" >> "%LOG_FILE%" 2>&1
    if errorlevel 1 (
        echo  [ERROR] Failed to create virtual environment. See %LOG_FILE%
        call :log "ERROR: venv creation failed"
        set /a ERROR_COUNT+=1
        goto :install_failed
    )
    echo  [OK] Virtual environment created
) else (
    echo  [OK] Virtual environment already exists
)

call :log "venv OK"

:: Paths inside venv
set "VENV_PYTHON=%VENV_DIR%\Scripts\python.exe"
set "VENV_PIP=%VENV_DIR%\Scripts\pip.exe"

if not exist "%VENV_PYTHON%" (
    echo  [ERROR] venv Python not found at: %VENV_PYTHON%
    echo  Try running: SETUP.bat --repair
    call :log "ERROR: venv python missing"
    set /a ERROR_COUNT+=1
    goto :install_failed
)

:: ============================================================
:: STEP 4 - Install dependencies
:: ============================================================
echo.
echo [Step 4/7] Installing dependencies...
call :log "--- Step 4: pip install ---"

if not exist "%SCOUT_DIR%\requirements.txt" (
    echo  [ERROR] requirements.txt not found at %SCOUT_DIR%
    call :log "ERROR: requirements.txt missing"
    set /a ERROR_COUNT+=1
    goto :install_failed
)

if "%FLAG_DEBUG%"=="1" (
    echo  Running pip install (debug mode - verbose output)...
    "%VENV_PIP%" install -r "%SCOUT_DIR%\requirements.txt" >> "%LOG_FILE%" 2>&1
) else (
    echo  Running pip install (this may take 1-3 minutes)...
    "%VENV_PIP%" install -q -r "%SCOUT_DIR%\requirements.txt" >> "%LOG_FILE%" 2>&1
    if errorlevel 1 (
        echo  Silent install failed, retrying with --no-cache-dir...
        call :log "pip silent install failed, retrying no-cache"
        "%VENV_PIP%" install --no-cache-dir -r "%SCOUT_DIR%\requirements.txt" >> "%LOG_FILE%" 2>&1
    )
)

if errorlevel 1 (
    echo  [ERROR] pip install failed. See %LOG_FILE%
    echo  Try running: SETUP.bat --repair --debug
    call :log "ERROR: pip install failed"
    set /a ERROR_COUNT+=1
    goto :install_failed
)

echo  [OK] All packages installed
call :log "pip install OK"

:: Quick import check
echo  Verifying key packages...
call :log "Verifying package imports"
"%VENV_PYTHON%" -c "import click, rich, httpx, praw, openpyxl, pandas, bs4, dotenv" >> "%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo  [WARNING] Some packages may not have imported correctly. See %LOG_FILE%
    call :log "WARNING: package import check failed"
) else (
    echo  [OK] Key packages verified
    call :log "Package imports OK"
)

:: ============================================================
:: STEP 5 - Create directories
:: ============================================================
echo.
echo [Step 5/7] Creating directories...
call :log "--- Step 5: directories ---"

for %%D in (databases exports logs) do (
    if not exist "%SCOUT_DIR%\%%D" (
        mkdir "%SCOUT_DIR%\%%D"
        call :log "Created: %%D"
        echo  Created: %%D\
    ) else (
        echo  [OK] %%D\ already exists
    )
)

:: ============================================================
:: STEP 6 - API Key Configuration
:: ============================================================
echo.
echo [Step 6/7] API Key Configuration...
call :log "--- Step 6: API keys ---"

if "%FLAG_SKIP_KEYS%"=="1" (
    echo  --skip-keys flag set: skipping API key setup.
    echo  Run SETUP.bat again without --skip-keys to configure keys.
    call :log "Skipping API keys (--skip-keys)"
    goto :keys_done
)

if exist "%ENV_FILE%" (
    echo.
    echo  An existing .env file was found.
    set /p "OVERWRITE_ENV=  Overwrite it with new keys? [y/N]: "
    if /i not "!OVERWRITE_ENV!"=="y" (
        echo  Keeping existing .env file.
        call :log "Keeping existing .env"
        goto :keys_done
    )
)

echo.
echo  ============================================================
echo   API Key Setup
echo   All keys are FREE. Press Enter to skip any key for now.
echo  ============================================================
echo.

:: SerpAPI
echo  [1/4] SerpAPI (100 free searches/month)
echo        Sign up: https://serpapi.com/users/sign_up
echo        Dashboard - API Key section
echo.
set /p "KEY_SERP=  Paste your SerpAPI key (or press Enter to skip): "
echo.

:: Open PageRank
echo  [2/4] Open PageRank (10,000 free/hour - permanently free)
echo        Sign up: https://www.domcop.com/openpagerank/
echo        Verify email, then Dashboard - API Key
echo.
set /p "KEY_OPR=  Paste your OPR key (or press Enter to skip): "
echo.

:: Reddit
echo  [3/4] Reddit API (free for personal use)
echo        Go to: https://www.reddit.com/prefs/apps
echo        Click "create another app" - select "script"
echo        Name: scout_link_tool  |  redirect: http://localhost:8080
echo        client_id = text under the app name (below "personal use script")
echo        client_secret = the "secret" field
echo.
set /p "KEY_REDDIT_ID=  Reddit client_id (or Enter to skip): "
set /p "KEY_REDDIT_SECRET=  Reddit client_secret (or Enter to skip): "
set /p "KEY_REDDIT_USER=  Your Reddit username (for user agent): "
if "!KEY_REDDIT_USER!"=="" set "KEY_REDDIT_USER=YOUR_USERNAME"
echo.

:: GitHub
echo  [4/4] GitHub Personal Access Token (free)
echo        Go to: https://github.com/settings/tokens
echo        Developer Settings - Personal Access Tokens - Tokens (classic)
echo        Generate new token - check "public_repo" scope
echo.
set /p "KEY_GITHUB=  Paste GitHub token (or Enter to skip): "
echo.

:: Write .env
call :log "Writing .env file"
(
    echo # Scout API Keys - generated by SETUP.bat
    echo # Edit this file any time to update your keys
    echo.
    echo # SerpAPI - 100 free searches/month - https://serpapi.com/users/sign_up
    echo SERPAPI_KEY=!KEY_SERP!
    echo.
    echo # Open PageRank - 10,000 free/hour - https://www.domcop.com/openpagerank/
    echo OPR_KEY=!KEY_OPR!
    echo.
    echo # Reddit - https://www.reddit.com/prefs/apps
    echo REDDIT_CLIENT_ID=!KEY_REDDIT_ID!
    echo REDDIT_CLIENT_SECRET=!KEY_REDDIT_SECRET!
    echo REDDIT_USER_AGENT=scout:v1.0 (by /u/!KEY_REDDIT_USER!)
    echo.
    echo # GitHub - https://github.com/settings/tokens
    echo GITHUB_TOKEN=!KEY_GITHUB!
) > "%ENV_FILE%"

echo  [OK] .env file written to: %ENV_FILE%
call :log ".env written"

:keys_done

:: Create .env from example if still missing
if not exist "%ENV_FILE%" (
    if exist "%SCOUT_DIR%\.env.example" (
        copy "%SCOUT_DIR%\.env.example" "%ENV_FILE%" >nul
        echo  [OK] .env created from .env.example (no keys entered)
        call :log ".env created from example"
    )
)

:: ============================================================
:: STEP 7 - Run verification tests
:: ============================================================
echo.
echo [Step 7/7] Running verification tests...
call :log "--- Step 7: verification ---"

if not exist "%SCOUT_DIR%\_verify.py" (
    echo  [WARNING] _verify.py not found - skipping tests
    call :log "WARNING: _verify.py missing"
    goto :verify_done
)

"%VENV_PYTHON%" "%SCOUT_DIR%\_verify.py"
set "VERIFY_EXIT=%errorlevel%"
call :log "Verification exit code: %VERIFY_EXIT%"

if "%VERIFY_EXIT%"=="0" (
    echo  [OK] All verification tests passed
) else (
    echo  [WARNING] Some tests failed. Scout may still work for most features.
    echo  Check the output above for details.
    call :log "WARNING: Some verification tests failed"
)

:verify_done

:: ============================================================
:: Generate launchers
:: ============================================================
call :log "--- Generating launchers ---"

:: scout.bat launcher
(
    echo @echo off
    echo :: Scout launcher - generated by SETUP.bat
    echo call "%VENV_DIR%\Scripts\activate.bat"
    echo python "%SCOUT_DIR%\main.py" %%*
) > "%SCOUT_DIR%\scout.bat"
call :log "Generated scout.bat"

:: repair.bat
(
    echo @echo off
    echo :: Scout repair - regenerated by SETUP.bat
    echo echo Repairing Scout installation...
    echo call "%SCOUT_DIR%\SETUP.bat" --repair
) > "%SCOUT_DIR%\repair.bat"
call :log "Generated repair.bat"

:: ============================================================
:: Summary
:: ============================================================
echo.
echo ============================================================
echo   Installation Complete
echo ============================================================
echo.

if %ERROR_COUNT% GTR 0 (
    echo  Completed with %ERROR_COUNT% error(s). Check %LOG_FILE%
) else (
    echo  All steps completed successfully.
)

echo.
echo  Quick start:
echo    scout.bat discover         - start a new discovery run
echo    scout.bat assess           - score discovered opportunities
echo    scout.bat export           - export results to Excel/CSV
echo    scout.bat status           - check API key status
echo    scout.bat --help           - all commands
echo.
echo  If you have not set API keys yet:
echo    Run SETUP.bat again (without --skip-keys)
echo    Or edit the .env file at: %ENV_FILE%
echo.
echo  Full log saved to: %LOG_FILE%
echo.
goto :eof

:: ============================================================
:: install_failed label
:: ============================================================
:install_failed
echo.
echo ============================================================
echo   Installation Failed
echo ============================================================
echo.
echo  %ERROR_COUNT% error(s) occurred. See: %LOG_FILE%
echo.
echo  Common fixes:
echo    - Python not found: reinstall from python.org (check "Add to PATH")
echo    - venv fails: run as Administrator or try SETUP.bat --repair
echo    - pip fails: check internet connection, try SETUP.bat --debug
echo.
exit /b 1

:: ============================================================
:: :log subroutine
:: ============================================================
:log
echo [%TIME%] %~1 >> "%LOG_FILE%"
goto :eof
