#!/usr/bin/env python3
"""
Scout verification script - tests all 20 modules + logic + DB + scoring
Run via: python _verify.py
"""
import sys
import os
import tempfile

# Add scout directory to path
SCOUT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCOUT_DIR)

passed = 0
failed = 0
errors = []

def test(name, fn):
    global passed, failed
    try:
        fn()
        print("  [PASS] " + name)
        passed += 1
    except Exception as e:
        print("  [FAIL] " + name + " -- " + str(e))
        errors.append(name + ": " + str(e))
        failed += 1

# --- Layer 0: Foundation ---
def t_config():
    import config
    assert hasattr(config, "RATE_LIMITS")
    assert hasattr(config, "SCORE_WEIGHTS")
    assert hasattr(config, "LINK_TYPES")
    assert len(config.LINK_TYPES) == 16

def t_logger():
    import utils.logger as lg
    log = lg.get_logger("test")
    assert log is not None

def t_helpers():
    import utils.helpers as h
    assert h.normalize_url("http://www.Example.com/") == "https://example.com"
    h1 = h.url_hash("http://www.example.com")
    h2 = h.url_hash("https://example.com")
    assert h1 == h2, "Hash mismatch: " + h1 + " vs " + h2
    assert h.extract_domain("https://www.sub.example.com/path") == "sub.example.com"

def t_database():
    import storage.database as db_mod
    from storage.database import Database, Opportunity, Project
    tmp = tempfile.mktemp(suffix=".db")
    try:
        db = Database(tmp)
        db.init_schema()
        pid = db.create_project(Project(client_name="Test", project_url="https://test.com",
                                        primary_keyword="test kw", secondary_keywords="a,b",
                                        niche="test", services="svc", location="US"))
        assert pid > 0
        opp = Opportunity(project_id=pid, url="https://test.com/page1", domain="test.com",
                          url_hash="abc123", link_type="Directories", source="test")
        oid = db.insert_opportunity(opp)
        assert oid is not None
        oid2 = db.insert_opportunity(opp)
        assert oid2 is None, "Duplicate should return None"
        db.close()
    finally:
        try: os.unlink(tmp)
        except: pass

def t_inputs():
    import inputs
    assert hasattr(inputs, "collect_inputs")

# --- Layer 1: Discovery Sources ---
def t_common_crawl():
    import discovery.sources.common_crawl as cc
    assert hasattr(cc, "discover_by_patterns")
    assert hasattr(cc, "query_cdx")

def t_serp_api():
    import discovery.sources.serp_api as sa
    assert hasattr(sa, "search")
    assert hasattr(sa, "batch_search")

def t_github_search():
    import discovery.sources.github_search as gh
    assert hasattr(gh, "discover")
    assert hasattr(gh, "search_repos")

def t_reddit_api():
    import discovery.sources.reddit_api as ra
    assert hasattr(ra, "discover")
    assert hasattr(ra, "BASE_SUBREDDITS")

# --- Layer 2: Discovery Engine ---
def t_footprints():
    from discovery.footprints import LINK_TYPE_CLASSES, get_footprints
    assert len(LINK_TYPE_CLASSES) == 16
    fp = get_footprints("Guest Posts", "seo tools", "marketing", "US", "consulting")
    assert "serp_queries" in fp
    assert "cdx_patterns" in fp
    assert len(fp["serp_queries"]) > 0

def t_discovery_engine():
    import discovery.engine as de
    assert hasattr(de, "DiscoveryEngine")

# --- Layer 3: Assessment Metrics ---
def t_open_pagerank():
    import assessment.metrics.open_pagerank as opr
    assert hasattr(opr, "get_pagerank_bulk")

def t_domain_age():
    import assessment.metrics.domain_age as da
    assert hasattr(da, "get_domain_age")

def t_http_check():
    import assessment.metrics.http_check as hc
    assert hasattr(hc, "check_url")

def t_relevance():
    from assessment.metrics.relevance import score_relevance
    s = score_relevance(
        url="https://personalinjurylawyer.com/resources",
        keywords=["personal injury lawyer", "accident attorney"],
        page_title="Personal Injury Lawyer Resources",
        meta_description="Find top personal injury lawyers",
        niche="legal"
    )
    assert s >= 3.5, "Expected >= 3.5, got " + str(s)

def t_scorer():
    from assessment.scorer import compute_score, assign_tier
    score, tier = compute_score(
        opr_score=5.0, domain_age_years=8, relevance_score=7.0,
        has_submission_page=True, has_contact_page=True,
        http_status=200, is_redirect=False, response_time_ms=500, is_parked=False
    )
    assert 0 <= score <= 100, "Score out of range: " + str(score)
    assert tier in ("A","B","C","D"), "Bad tier: " + tier
    assert assign_tier(85) == "A"
    assert assign_tier(65) == "B"
    assert assign_tier(45) == "C"
    assert assign_tier(25) == "D"

def t_assessment_engine():
    import assessment.engine as ae
    assert hasattr(ae, "AssessmentEngine")

# --- Layer 4: Output ---
def t_export():
    import storage.export as exp
    assert hasattr(exp, "export_csv")
    assert hasattr(exp, "export_excel")

def t_reporter():
    import reports.reporter as rpt
    assert hasattr(rpt, "print_discovery_summary")
    assert hasattr(rpt, "print_assessment_summary")

def t_main():
    import main
    assert hasattr(main, "cli")

# --- Logic tests ---
def t_dedup():
    import utils.helpers as h
    urls = ["http://www.example.com", "https://example.com", "https://example.com/"]
    hashes = set(h.url_hash(u) for u in urls)
    assert len(hashes) == 1, "All 3 variants should produce the same hash"

def t_scoring_weights():
    import config
    total = sum(config.SCORE_WEIGHTS.values())
    assert total == 100, "Score weights must sum to 100, got " + str(total)

def t_db_bulk_insert():
    from storage.database import Database, Opportunity, Project
    tmp = tempfile.mktemp(suffix=".db")
    try:
        db = Database(tmp)
        db.init_schema()
        pid = db.create_project(Project(client_name="Bulk", project_url="https://bulk.com",
                                        primary_keyword="bulk kw", secondary_keywords="",
                                        niche="bulk", services="", location=""))
        opps = []
        for i in range(5):
            opps.append(Opportunity(project_id=pid, url="https://site" + str(i) + ".com",
                                    domain="site" + str(i) + ".com",
                                    url_hash="hash" + str(i),
                                    link_type="Directories", source="test"))
        # Add a duplicate
        opps.append(Opportunity(project_id=pid, url="https://site0.com",
                                domain="site0.com", url_hash="hash0",
                                link_type="Directories", source="test"))
        inserted, skipped = db.bulk_insert_opportunities(opps)
        assert inserted == 5, "Expected 5 inserted, got " + str(inserted)
        assert skipped == 1, "Expected 1 skipped, got " + str(skipped)
        db.close()
    finally:
        try: os.unlink(tmp)
        except: pass

# Run all tests
print("")
print("=" * 60)
print("  Scout Verification Suite")
print("=" * 60)
print("")

print("[Layer 0] Foundation")
test("config.py", t_config)
test("utils/logger.py", t_logger)
test("utils/helpers.py", t_helpers)
test("storage/database.py", t_database)
test("inputs.py", t_inputs)

print("")
print("[Layer 1] Discovery Sources")
test("discovery/sources/common_crawl.py", t_common_crawl)
test("discovery/sources/serp_api.py", t_serp_api)
test("discovery/sources/github_search.py", t_github_search)
test("discovery/sources/reddit_api.py", t_reddit_api)

print("")
print("[Layer 2] Discovery Engine")
test("discovery/footprints.py", t_footprints)
test("discovery/engine.py", t_discovery_engine)

print("")
print("[Layer 3] Assessment Metrics")
test("assessment/metrics/open_pagerank.py", t_open_pagerank)
test("assessment/metrics/domain_age.py", t_domain_age)
test("assessment/metrics/http_check.py", t_http_check)
test("assessment/metrics/relevance.py", t_relevance)
test("assessment/scorer.py", t_scorer)
test("assessment/engine.py", t_assessment_engine)

print("")
print("[Layer 4] Output")
test("storage/export.py", t_export)
test("reports/reporter.py", t_reporter)
test("main.py", t_main)

print("")
print("[Logic]")
test("URL deduplication hash consistency", t_dedup)
test("Score weights sum to 100", t_scoring_weights)
test("Bulk insert dedup", t_db_bulk_insert)

print("")
print("=" * 60)
total = passed + failed
print("  Results: " + str(passed) + "/" + str(total) + " passed")
if errors:
    print("")
    print("  Failures:")
    for e in errors:
        print("    - " + e)
print("=" * 60)
print("")

sys.exit(0 if failed == 0 else 1)
