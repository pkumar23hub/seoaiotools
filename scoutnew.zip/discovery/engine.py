"""
discovery/engine.py — Main Discovery Engine orchestrator.

Drives all 16 link types across 4 source layers (CDX, SerpAPI, GitHub, Reddit).
Deduplicates results globally and inserts into the database.
Supports session resume — skips link types already completed in this run.

Usage:
    from discovery.engine import DiscoveryEngine
    engine = DiscoveryEngine(db, project, keyword_set)
    count = engine.run()
"""

import json
from datetime import datetime
from typing import Optional

from utils.logger import get_logger
from utils.helpers import extract_domain, url_hash
from storage.database import Database, Opportunity
from discovery.footprints import get_footprints, LINK_TYPE_CLASSES
from discovery.sources import common_crawl, serp_api, github_search, reddit_api
import config

logger = get_logger(__name__)


class DiscoveryEngine:
    """
    Orchestrates discovery across all link types and sources.

    Attributes:
        db          : Database instance (must be connected)
        project     : dict from db.get_project()
        keywords    : list of keyword strings from inputs.get_keyword_set()
    """

    def __init__(self, db: Database, project: dict, keywords: list[str]):
        self.db       = db
        self.project  = project
        self.keywords = keywords
        self.project_id = project["id"]

        # Primary keyword for footprint injection
        self.kw      = project.get("primary_kw", "")
        self.niche   = project.get("category", "")
        self.loc     = project.get("location", "")
        self.service = project.get("services", "").split(",")[0].strip()

        # Global dedup hash set across all link types in this run
        self._seen_hashes: set = set()

        # Load existing URL hashes from DB to avoid re-inserting past runs
        self._load_existing_hashes()

    def _load_existing_hashes(self):
        """Pre-load all known URL hashes to avoid duplicates across runs."""
        rows = self.db.conn.execute(
            "SELECT url_hash FROM opportunities WHERE project_id=?",
            (self.project_id,)
        ).fetchall()
        for row in rows:
            self._seen_hashes.add(row["url_hash"])
        logger.debug(f"Pre-loaded {len(self._seen_hashes)} existing hashes")

    def run(
        self,
        link_types: list[str] = None,
        sources: list[str] = None,
    ) -> int:
        """
        Run discovery for all (or specified) link types.

        Args:
            link_types: Subset of LINK_TYPES to run. None = all 16.
            sources:    Subset of ['cdx','serp','github','reddit']. None = all.

        Returns:
            Total new opportunities inserted.
        """
        if link_types is None:
            link_types = list(LINK_TYPE_CLASSES.keys())
        if sources is None:
            sources = ["cdx", "serp", "github", "reddit"]

        run_id = self.db.log_run_start(
            self.project_id, "discovery", sources
        )

        total_inserted = 0
        total_skipped  = 0

        logger.info(f"Starting discovery for project #{self.project_id}")
        logger.info(f"Link types: {len(link_types)}  |  Sources: {sources}")
        logger.info(f"Keywords: {self.keywords[:3]}...")

        for lt in link_types:
            logger.info(f"\n[{lt}]")
            inserted, skipped = self._discover_link_type(lt, sources)
            total_inserted += inserted
            total_skipped  += skipped
            logger.info(f"  → +{inserted} new (skipped {skipped} dupes)")

        self.db.log_run_end(run_id, total_inserted)

        logger.info(f"\nDiscovery complete: {total_inserted} new opportunities "
                    f"({total_skipped} duplicates filtered)")
        return total_inserted

    def _discover_link_type(
        self,
        link_type: str,
        sources: list[str],
    ) -> tuple[int, int]:
        """Run all enabled sources for one link type. Returns (inserted, skipped)."""
        fp = get_footprints(
            link_type,
            kw      = self.kw,
            niche   = self.niche,
            loc     = self.loc,
            service = self.service,
        )

        raw_results: list[dict] = []

        # ── Common Crawl CDX ──────────────────────────────────────────────────
        if "cdx" in sources and fp["cdx_patterns"]:
            cc_results = common_crawl.discover_by_patterns(
                fp["cdx_patterns"],
                limit_per_pattern=config.CC_RESULTS_PER_PATTERN,
            )
            for r in cc_results:
                r["source"] = "common_crawl"
            raw_results.extend(cc_results)

        # ── SerpAPI ───────────────────────────────────────────────────────────
        if "serp" in sources and fp["serp_queries"]:
            # Use top 3 SERP queries per link type to conserve budget
            top_queries = fp["serp_queries"][:3]
            serp_results = serp_api.batch_search(top_queries, db=self.db)
            for r in serp_results:
                r["source"] = "serp_api"
            raw_results.extend(serp_results)

        # ── GitHub ────────────────────────────────────────────────────────────
        if "github" in sources and fp["github_queries"]:
            gh_results = github_search.discover(fp["github_queries"][:2])
            for r in gh_results:
                r["source"] = "github"
            raw_results.extend(gh_results)

        # ── Reddit ────────────────────────────────────────────────────────────
        if "reddit" in sources and fp["reddit_queries"]:
            rd_results = reddit_api.discover(
                fp["reddit_queries"][:2],
                niche=self.niche,
            )
            for r in rd_results:
                r["source"] = "reddit"
            raw_results.extend(rd_results)

        # ── Deduplicate + Build Opportunity objects ───────────────────────────
        opps_to_insert: list[Opportunity] = []
        for r in raw_results:
            url = r.get("url", "")
            if not url:
                continue
            h = url_hash(url)
            if h in self._seen_hashes:
                continue
            self._seen_hashes.add(h)
            opps_to_insert.append(Opportunity(
                project_id     = self.project_id,
                url            = url,
                domain         = extract_domain(url),
                link_type      = link_type,
                url_hash       = h,
                discovered_via = r.get("source", ""),
            ))

        inserted, skipped = self.db.bulk_insert_opportunities(opps_to_insert)
        return inserted, skipped


if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")
    from storage.database import Project

    # Dry-run test with a temp DB (CDX queries will fail in sandbox but logic is tested)
    import tempfile
    from pathlib import Path

    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        tmp_path = Path(f.name)

    db = Database(db_path=tmp_path)
    db.connect()

    pid = db.create_project(Project(
        client_name="Test",
        project_url="https://test.com",
        primary_kw="seo agency",
        category="Marketing",
        location="London",
        services="SEO",
    ))
    project = db.get_project(pid)
    keywords = ["seo agency", "digital marketing", "link building", "London"]

    engine = DiscoveryEngine(db, project, keywords)

    # Test with CDX disabled (network unavailable in sandbox)
    # and SERP/GitHub/Reddit which gracefully handle missing keys
    count = engine.run(
        link_types=["Guest Posts", "Directories"],
        sources=["serp", "github", "reddit"],  # skip cdx in sandbox
    )
    print(f"\nDry-run inserted: {count} opportunities")

    stats = db.summary_stats(pid)
    print(f"DB stats: {stats}")
    db.close()

    import os
    os.unlink(tmp_path)
    print("Discovery engine test complete")
