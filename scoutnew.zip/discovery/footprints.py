"""
discovery/footprints.py — All footprint templates for 16 link types.

Each link type has:
  - serp_queries(kw, niche, loc, service): list of Google footprint strings
  - cdx_patterns(): list of CC CDX URL patterns (no keyword injection needed)
  - github_queries(niche): list of GitHub search strings
  - reddit_queries(kw, niche): list of Reddit search strings

The discovery engine calls these functions per link type.
"""

from typing import Optional


# ── Helper ────────────────────────────────────────────────────────────────────

def _q(*parts) -> str:
    """Join non-empty parts into a query string."""
    return " ".join(p for p in parts if p)


# ══════════════════════════════════════════════════════════════════════════════
#  1. DIRECTORIES
# ══════════════════════════════════════════════════════════════════════════════

class Directories:
    LINK_TYPE = "Directories"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'"{niche} directory"', '"submit" OR "add listing" OR "suggest a site"'),
            _q(f'inurl:directory "{niche}"', '"submit your site"'),
            _q(f'"{niche}"', f'"{loc}"' if loc else "", '"business directory" "add business"'),
            _q(f'intitle:"directory" "{niche}"', '"free listing"'),
            _q(f'"{kw}"', '"free web directory" "submit"'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*/submit-site*",
            "*/add-listing*",
            "*/add-url*",
            "*/suggest-site*",
            "*/submit-link*",
            "*/free-directory*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            f"awesome {niche} directory resources list",
            "free business directory list submission sites",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            "directory submission sites list free",
            f"{niche} directory listing free",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  2. LOCAL CITATIONS
# ══════════════════════════════════════════════════════════════════════════════

class LocalCitations:
    LINK_TYPE = "Local Citations"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'"{loc}"' if loc else "", f'"{niche}"', '"add your business" OR "claim your listing"'),
            _q(f'"{loc}"' if loc else "", f'"{service}"', '"NAP" OR "business listing" "free"'),
            _q(f'"{niche}"', f'"{loc}"' if loc else "", '"chamber of commerce" "member directory"'),
            _q(f'inurl:"/biz/" OR inurl:"/business/"', f'"{niche}"', '"submit"'),
            _q(f'"{kw}"', f'"{loc}"' if loc else "", '"local citation" "free listing"'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*/business-directory*",
            "*/local-listing*",
            "*/add-business*",
            "*/claim-listing*",
            "*.yelp.com/biz/*",
            "*.yellowpages.com/*",
            "*.manta.com/c/*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            f"{niche} local citation sites list",
            "local SEO citation directories list",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            "local citation sites list SEO",
            f"{niche} local listing directories",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  3. PROFILE LINKS
# ══════════════════════════════════════════════════════════════════════════════

class ProfileLinks:
    LINK_TYPE = "Profile Links"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'"{niche}"', '"create profile" OR "member profile"', '"website link"'),
            _q(f'"{niche}"', 'community "signature" "website link"'),
            _q(f'"{kw}"', '"expert profile" OR "author bio"', '"website"'),
            _q('site:about.me OR site:crunchbase.com', f'"{niche}"'),
            _q(f'"{niche}"', '"register free" "profile URL"'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*.about.me/*",
            "*.crunchbase.com/person/*",
            "*.gravatar.com/*",
            "*/member-profile*",
            "*/user-profile*",
            "*/author-bio*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            f"{niche} profile link building sites",
            "high authority profile link sites list",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            "profile link building sites dofollow",
            f"{niche} profile backlink sites",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  4. SOCIAL BOOKMARKING
# ══════════════════════════════════════════════════════════════════════════════

class SocialBookmarking:
    LINK_TYPE = "Social Bookmarking"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'site:mix.com OR site:pearltrees.com OR site:diigo.com', f'"{kw}"'),
            _q(f'"{kw}"', '"social bookmarking" "submit link"'),
            _q(f'"{niche}"', '"bookmark" "share" "save" free'),
            _q('site:scoop.it', f'"{niche}"'),
            _q(f'"{kw}"', '"bookmarking site" "dofollow"'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*.mix.com/*",
            "*.pearltrees.com/*",
            "*.diigo.com/*",
            "*.scoop.it/*",
            "*.folkd.com/*",
            "*.bizsugar.com/*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            "social bookmarking sites list dofollow 2024",
            f"{niche} social bookmarking submission",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            "social bookmarking sites list high DA",
            f"{niche} social sharing sites",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  5. PDF SHARING
# ══════════════════════════════════════════════════════════════════════════════

class PDFSharing:
    LINK_TYPE = "PDF Sharing"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'site:scribd.com OR site:slideshare.net', f'"{kw}"', 'filetype:pdf'),
            _q(f'"{niche}"', '"upload PDF" OR "share document" "free"'),
            _q(f'site:issuu.com', f'"{niche}" "publication"'),
            _q(f'"{kw}"', '"PDF guide" OR "whitepaper"', '"share" "upload"'),
            _q(f'site:academia.edu OR site:researchgate.net', f'"{niche}"'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*.scribd.com/doc/*",
            "*.issuu.com/*/docs/*",
            "*.academia.edu/*.pdf",
            "*/upload-pdf*",
            "*/share-document*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            f"{niche} PDF sharing sites list",
            "document sharing sites free upload",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            "PDF sharing sites backlinks list",
            f"{niche} document sharing platforms",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  6. PPT SHARING
# ══════════════════════════════════════════════════════════════════════════════

class PPTSharing:
    LINK_TYPE = "PPT Sharing"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'site:slideshare.net', f'"{kw}" OR "{niche}" "presentation"'),
            _q(f'"{niche}"', '"upload presentation" OR "share slides" "free"'),
            _q(f'site:authorstream.com OR site:slideserve.com', f'"{kw}"'),
            _q(f'"{niche}"', '"PowerPoint" OR "slides" "free hosting" "share"'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*.slideshare.net/*",
            "*.slideserve.com/*",
            "*.authorstream.com/*",
            "*/upload-presentation*",
            "*/share-slides*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            "PPT presentation sharing sites list free",
            f"{niche} slideshow hosting platforms",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            "presentation sharing sites SEO backlinks",
            f"{niche} PPT upload sites",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  7. IMAGE SHARING
# ══════════════════════════════════════════════════════════════════════════════

class ImageSharing:
    LINK_TYPE = "Image Sharing"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'site:flickr.com OR site:500px.com', f'"{niche}"'),
            _q(f'"{niche}"', '"image gallery" "submit photo" OR "upload image"'),
            _q(f'"{kw}"', '"infographic" "share" "embed" "submit"'),
            _q(f'site:pinterest.com', f'"{niche}" "board" "contributor"'),
            _q(f'"{niche}"', '"photo sharing" "free" "website link"'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*.flickr.com/photos/*",
            "*.500px.com/photo/*",
            "*.deviantart.com/*",
            "*/submit-infographic*",
            "*/infographic-submission*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            "image sharing sites list backlinks",
            f"{niche} photo hosting platform submission",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            "infographic submission sites list",
            f"{niche} image sharing backlink sites",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  8. WEB 2.0
# ══════════════════════════════════════════════════════════════════════════════

class Web20:
    LINK_TYPE = "Web 2.0"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'site:wordpress.com OR site:blogspot.com', f'"{kw}"'),
            _q(f'site:wix.com OR site:weebly.com OR site:tumblr.com', f'"{niche}"'),
            _q(f'"{niche}"', '"free blog" "create site" web 2.0'),
            _q(f'site:medium.com', f'"{kw}" OR "{niche}" "author"'),
            _q(f'site:sites.google.com', f'"{niche}" "{kw}"'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*.wordpress.com/*",
            "*.blogspot.com/*",
            "*.tumblr.com/*",
            "*.weebly.com/*",
            "*.blogger.com/*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            "web 2.0 sites list blogging platforms free",
            f"{niche} web 2.0 backlink platforms",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            "web 2.0 sites list 2024 backlinks",
            f"{niche} free blogging platforms link building",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  9. FORUMS
# ══════════════════════════════════════════════════════════════════════════════

class Forums:
    LINK_TYPE = "Forums"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'"{niche}"', 'forum "powered by phpBB" OR "powered by vBulletin" OR "powered by XenForo"'),
            _q(f'"{kw}"', '"discussion board" "post reply" "register"'),
            _q(f'"{niche} forum"', '"join" "signature link" "member"'),
            _q(f'"{niche}"', 'community inurl:forum OR inurl:board'),
            _q(f'"{loc}"' if loc else "", f'"{niche}"', 'forum "introduce yourself"'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*/forum/index*",
            "*/board/index*",
            "*/forums/*",
            "*/community/forum*",
            "*phpbb*index.php*",
            "*/viewforum*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            f"{niche} community forums list active",
            "niche forum list link building signature",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            f"{niche} best forums discussion boards",
            "forum link building signature backlinks",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  10. BLOG COMMENTS
# ══════════════════════════════════════════════════════════════════════════════

class BlogComments:
    LINK_TYPE = "Blog Comments"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'"{niche}"', '"leave a comment" OR "post a comment" "website" field'),
            _q(f'"{kw}"', 'blog "add comment" -"comments closed"'),
            _q(f'"{niche}"', 'inurl:blog "CommentLuv" OR "KeywordLuv"'),
            _q(f'"{kw}"', '"recent comments" "website" "URL"'),
            _q(f'"{niche}"', '"reply" "your website" intitle:blog'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*/blog/*/comment*",
            "*/leave-a-comment*",
            "*commentluv*",
            "*/blog/*#comment*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            f"{niche} blog comment sites list dofollow",
            "CommentLuv enabled blogs list",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            "blog comment backlinks dofollow sites",
            f"{niche} blog comment link building",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  11. Q&A
# ══════════════════════════════════════════════════════════════════════════════

class QAndA:
    LINK_TYPE = "Q&A"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'site:quora.com', f'"{kw}" OR "{niche}"'),
            _q(f'"{niche}"', '"ask a question" OR "answer questions" Q&A "free"'),
            _q(f'site:stackexchange.com', f'"{niche}"'),
            _q(f'"{kw}"', '"questions and answers" "community" "source:"'),
            _q(f'"{niche}"', '"answers" "community forum" "link in bio"'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*.quora.com/What*",
            "*.quora.com/How*",
            "*.stackexchange.com/questions/*",
            "*/ask-a-question*",
            "*/qa/*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            f"{niche} Q&A sites list",
            "question answer sites link building list",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            f"{niche} question answer communities",
            "Q&A sites backlinks SEO",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  12. WIKI LINKS
# ══════════════════════════════════════════════════════════════════════════════

class WikiLinks:
    LINK_TYPE = "Wiki Links"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'site:wikipedia.org', f'"{niche}"', '"external links"'),
            _q(f'"{kw}"', 'wiki "add link" OR "edit" "external links"'),
            _q(f'site:wikia.com OR site:fandom.com', f'"{niche}"'),
            _q(f'"{niche}"', '"community wiki" "contribute" "add resource"'),
            _q(f'inurl:wiki', f'"{niche}"', '"references" "further reading"'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*/wiki/*",
            "*.wikia.com/*",
            "*.fandom.com/wiki/*",
            "*/mediawiki/*",
            "*/w/index.php*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            f"{niche} wiki sites list editable",
            "wiki link building sites list",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            f"{niche} wiki communities contribute links",
            "wiki link building strategy sites",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  13. PARASITE SEO
# ══════════════════════════════════════════════════════════════════════════════

class ParasiteSEO:
    LINK_TYPE = "Parasite SEO"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'site:medium.com OR site:linkedin.com/pulse', f'"{kw}" "author"'),
            _q(f'site:hubpages.com OR site:vocal.media', f'"{niche}" "write"'),
            _q(f'"{niche}"', '"publish article" "high authority" "free"'),
            _q(f'site:sites.google.com OR site:notion.site', f'"{niche}" "published"'),
            _q(f'"{kw}"', '"guest author" "publish free" high authority'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*.medium.com/*",
            "*.linkedin.com/pulse/*",
            "*.hubpages.com/hub/*",
            "*.vocal.media/*",
            "*.sites.google.com/*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            "high authority article publishing platforms free",
            f"{niche} parasite SEO platforms list",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            "parasite SEO platforms high authority publishing",
            f"{niche} free article publishing platforms",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  14. GUEST POSTS
# ══════════════════════════════════════════════════════════════════════════════

class GuestPosts:
    LINK_TYPE = "Guest Posts"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'"{niche}"', '"write for us" "guest post" OR "contribute an article"'),
            _q(f'"{niche}"', '"guest blogger" OR "guest author" "submit"'),
            _q(f'"{kw}"', '"accepting guest posts" OR "guest post guidelines"'),
            _q(f'"{niche}" intitle:"write for us"'),
            _q(f'"{niche} blog" "submission guidelines" "contributor"'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*/write-for-us*",
            "*/write-for-us/*",
            "*/guest-post*",
            "*/contribute*",
            "*/submission-guidelines*",
            "*/guest-author*",
            "*/become-a-contributor*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            f"{niche} write for us guest post sites list",
            f"awesome {niche} blogs accepting guest posts",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            f"{niche} blogs accepting guest posts",
            "write for us sites list guest blogging",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  15. NICHE EDITS
# ══════════════════════════════════════════════════════════════════════════════

class NicheEdits:
    LINK_TYPE = "Niche Edits"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'"{niche}"', '"resources" OR "useful links" OR "recommended sites" inurl:resources'),
            _q(f'"{kw}"', '"link roundup" OR "weekly roundup" "submit"'),
            _q(f'"{niche}"', f'"best {service} tools" OR "best {kw} sites"', '"add your site"'),
            _q(f'"{niche}"', 'intitle:"resources" "external links" -wikipedia'),
            _q(f'"{loc}"' if loc else "", f'"{niche}"', '"recommended" "links" site:.org OR site:.edu'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*/resources*",
            "*/useful-links*",
            "*/recommended*",
            "*/link-roundup*",
            "*/best-of*",
            "*/resource-page*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            f"{niche} resource page link opportunities",
            f"awesome {niche} curated list links",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            f"{niche} link roundup resource pages",
            "niche edit link opportunities resource pages",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  16. EDITORIAL LINKS
# ══════════════════════════════════════════════════════════════════════════════

class EditorialLinks:
    LINK_TYPE = "Editorial Links"

    @staticmethod
    def serp_queries(kw: str, niche: str, loc: str, service: str) -> list[str]:
        return [
            _q(f'"{kw}"', '"according to" OR "source:" OR "via" site:.com -site:wikipedia.org'),
            _q(f'"{niche}"', '"statistics" OR "study" OR "research" "cite" "link to"'),
            _q(f'"{kw} guide" OR "{kw} tips"', '"authoritative" "reference"'),
            _q(f'"{niche}"', '"expert roundup" OR "industry report" "contributor"'),
            _q(f'"{kw}"', '"best practices" "link" site:.org OR site:.edu'),
        ]

    @staticmethod
    def cdx_patterns() -> list[str]:
        return [
            "*/statistics*",
            "*/research*",
            "*/industry-report*",
            "*/study*",
            "*/data-report*",
            "*/expert-roundup*",
        ]

    @staticmethod
    def github_queries(niche: str) -> list[str]:
        return [
            f"{niche} statistics data sources citations",
            f"awesome {niche} research reports",
        ]

    @staticmethod
    def reddit_queries(kw: str, niche: str) -> list[str]:
        return [
            f"{niche} statistics research data sources",
            "editorial link building strategy sites",
        ]


# ══════════════════════════════════════════════════════════════════════════════
#  REGISTRY — maps link type name → class
# ══════════════════════════════════════════════════════════════════════════════

LINK_TYPE_CLASSES = {
    "Directories":       Directories,
    "Local Citations":   LocalCitations,
    "Profile Links":     ProfileLinks,
    "Social Bookmarking": SocialBookmarking,
    "PDF Sharing":       PDFSharing,
    "PPT Sharing":       PPTSharing,
    "Image Sharing":     ImageSharing,
    "Web 2.0":           Web20,
    "Forums":            Forums,
    "Blog Comments":     BlogComments,
    "Q&A":               QAndA,
    "Wiki Links":        WikiLinks,
    "Parasite SEO":      ParasiteSEO,
    "Guest Posts":       GuestPosts,
    "Niche Edits":       NicheEdits,
    "Editorial Links":   EditorialLinks,
}


def get_footprints(
    link_type: str,
    kw: str,
    niche: str,
    loc: str,
    service: str,
) -> dict:
    """
    Return all footprint queries for a link type, injected with project keywords.

    Returns dict:
        serp_queries   : list[str]
        cdx_patterns   : list[str]
        github_queries : list[str]
        reddit_queries : list[str]
    """
    cls = LINK_TYPE_CLASSES.get(link_type)
    if not cls:
        return {"serp_queries": [], "cdx_patterns": [], "github_queries": [], "reddit_queries": []}

    return {
        "serp_queries":   cls.serp_queries(kw, niche, loc, service),
        "cdx_patterns":   cls.cdx_patterns(),
        "github_queries": cls.github_queries(niche),
        "reddit_queries": cls.reddit_queries(kw, niche),
    }


if __name__ == "__main__":
    fp = get_footprints(
        "Guest Posts",
        kw="personal injury lawyer",
        niche="Legal",
        loc="Houston TX",
        service="Personal Injury",
    )
    print("Guest Posts SERP queries:")
    for q in fp["serp_queries"]:
        print(f"  {q}")
    print(f"\nCDX patterns: {fp['cdx_patterns'][:3]}")
    print(f"\nAll 16 link types registered: {len(LINK_TYPE_CLASSES)}")
    assert len(LINK_TYPE_CLASSES) == 16, "Expected 16 link types"
    print("Footprints test PASSED")
