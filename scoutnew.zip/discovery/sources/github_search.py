"""
discovery/sources/github_search.py — GitHub Search API source.

Searches GitHub for curated resource lists (awesome-* repos, wiki pages,
README.md files containing outbound links). Extracts https:// URLs from
matching file content.

Free limit: 30 requests/minute with a personal access token.
No token: 10 requests/minute (unauthenticated, sufficient for our use).
"""

import re
import time
import requests
from typing import Optional

from utils.logger import get_logger
from utils.helpers import is_valid_url, extract_domain, url_hash, sleep_rate
import config

logger = get_logger(__name__)

GITHUB_SEARCH_URL = "https://api.github.com/search/code"
GITHUB_REPO_SEARCH_URL = "https://api.github.com/search/repositories"
RAW_CONTENT_URL   = "https://raw.githubusercontent.com/{repo}/HEAD/{path}"


def _headers() -> dict:
    h = {
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "Scout/1.0",
    }
    if config.GITHUB_TOKEN:
        h["Authorization"] = f"token {config.GITHUB_TOKEN}"
    return h


def search_repos(query: str, max_results: int = None) -> list[dict]:
    """
    Search GitHub repositories matching the query.
    Returns list of {name, full_name, html_url, description, stars}.
    """
    if max_results is None:
        max_results = config.GITHUB_RESULTS_PER_QUERY

    try:
        resp = requests.get(
            GITHUB_REPO_SEARCH_URL,
            headers=_headers(),
            params={"q": query, "sort": "stars", "per_page": max_results},
            timeout=15,
        )
        if resp.status_code == 403:
            logger.warning("GitHub rate limit hit. Sleeping 60s...")
            time.sleep(60)
            return []
        resp.raise_for_status()
        items = resp.json().get("items", [])
        results = []
        for item in items:
            results.append({
                "full_name":   item.get("full_name", ""),
                "html_url":    item.get("html_url", ""),
                "description": item.get("description", ""),
                "stars":       item.get("stargazers_count", 0),
            })
        logger.debug(f"GitHub repos: '{query[:50]}' → {len(results)}")
        sleep_rate("github")
        return results

    except Exception as e:
        logger.error(f"GitHub repo search error: {e}")
        return []


def extract_urls_from_readme(repo_full_name: str) -> list[str]:
    """
    Fetch README.md from a repo and extract all https:// URLs.
    Returns deduplicated list of external URLs (excludes github.com itself).
    """
    raw_url = f"https://raw.githubusercontent.com/{repo_full_name}/HEAD/README.md"
    try:
        resp = requests.get(raw_url, timeout=10, headers={"User-Agent": "Scout/1.0"})
        if resp.status_code != 200:
            return []
        text = resp.text
        # Extract all https URLs from markdown
        found = re.findall(r'https?://[^\s\)\]"\'<>]+', text)
        # Filter: valid URL, not github.com, not shields.io/badges
        urls = []
        seen = set()
        skip_domains = {"github.com", "shields.io", "travis-ci.org", "codecov.io",
                        "badge", "img.shields", "raw.githubusercontent.com"}
        for url in found:
            url = url.rstrip(".,;)")
            if not is_valid_url(url):
                continue
            dom = extract_domain(url)
            if any(s in dom for s in skip_domains):
                continue
            if url not in seen:
                seen.add(url)
                urls.append(url)
        return urls[:50]  # cap at 50 per README

    except Exception as e:
        logger.debug(f"README fetch failed for {repo_full_name}: {e}")
        return []


def discover(queries: list[str]) -> list[dict]:
    """
    For each query, search repos and extract URLs from their READMEs.

    Returns list of {url, domain, url_hash, source_repo, github_query}.
    """
    seen_hashes = set()
    results = []

    for query in queries:
        logger.info(f"  GitHub search: {query}")
        repos = search_repos(query, max_results=5)  # top 5 repos per query

        for repo in repos:
            fname = repo.get("full_name", "")
            if not fname:
                continue
            urls = extract_urls_from_readme(fname)
            logger.debug(f"  Repo {fname}: {len(urls)} URLs extracted")

            for url in urls:
                h = url_hash(url)
                if h not in seen_hashes:
                    seen_hashes.add(h)
                    results.append({
                        "url":          url,
                        "domain":       extract_domain(url),
                        "url_hash":     h,
                        "source_repo":  fname,
                        "github_query": query,
                    })
            sleep_rate("github")

    return results


if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")

    print("Testing GitHub Search source...")
    results = discover(["awesome seo link building resources"])
    print(f"  Got {len(results)} URLs from GitHub")
    if results:
        print(f"  Sample: {results[0]['url']} (from {results[0]['source_repo']})")
    print("GitHub source test complete")
