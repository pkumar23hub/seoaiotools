"""
discovery/sources/reddit_api.py — Reddit API source via PRAW.

Searches subreddits for resource threads, roundup posts, and "useful links"
discussions. Extracts external URLs from post bodies and comments.

Falls back to unauthenticated JSON endpoint if PRAW credentials not set.
"""

import re
import time
import requests
from typing import Optional

from utils.logger import get_logger
from utils.helpers import is_valid_url, extract_domain, url_hash, sleep_rate
import config

logger = get_logger(__name__)

# Subreddits to always search (supplemented by niche-specific ones)
BASE_SUBREDDITS = ["SEO", "bigseo", "linkbuilding", "juststart", "Blogging"]

# Reddit public JSON endpoint (no auth, 60 req/min)
REDDIT_JSON_URL = "https://www.reddit.com/r/{subreddit}/search.json"


def _get_praw_reddit():
    """Return authenticated PRAW Reddit instance, or None if not configured."""
    if not (config.REDDIT_CLIENT_ID and config.REDDIT_CLIENT_SECRET):
        return None
    try:
        import praw
        reddit = praw.Reddit(
            client_id=config.REDDIT_CLIENT_ID,
            client_secret=config.REDDIT_CLIENT_SECRET,
            user_agent=config.REDDIT_USER_AGENT,
        )
        # Test connection
        reddit.user.me()  # will raise if auth fails
        return reddit
    except Exception as e:
        logger.warning(f"PRAW auth failed ({e}). Using public JSON fallback.")
        return None


def _extract_urls_from_text(text: str) -> list[str]:
    """Extract all valid external https:// URLs from a text block."""
    found = re.findall(r'https?://[^\s\)\]"\'<>]+', text)
    skip = {"reddit.com", "redd.it", "imgur.com", "i.imgur", "preview.redd"}
    urls = []
    seen = set()
    for url in found:
        url = url.rstrip(".,;)")
        if not is_valid_url(url):
            continue
        dom = extract_domain(url)
        if any(s in dom for s in skip):
            continue
        if url not in seen:
            seen.add(url)
            urls.append(url)
    return urls


def search_subreddit_json(
    subreddit: str,
    query: str,
    limit: int = None,
) -> list[dict]:
    """
    Search a subreddit via public Reddit JSON (no auth needed).
    Returns list of post dicts with selftext included.
    """
    if limit is None:
        limit = config.REDDIT_RESULTS_PER_QUERY

    url = REDDIT_JSON_URL.format(subreddit=subreddit)
    params = {
        "q":       query,
        "sort":    "relevance",
        "limit":   limit,
        "restrict_sr": True,
        "type":    "link,self",
    }
    headers = {"User-Agent": config.REDDIT_USER_AGENT or "Scout/1.0"}

    try:
        resp = requests.get(url, params=params, headers=headers, timeout=15)
        if resp.status_code == 429:
            logger.warning("Reddit rate limited. Sleeping 30s...")
            time.sleep(30)
            return []
        if resp.status_code != 200:
            logger.debug(f"Reddit JSON {resp.status_code} for r/{subreddit} '{query}'")
            return []

        data = resp.json()
        posts = data.get("data", {}).get("children", [])
        return [p.get("data", {}) for p in posts]

    except Exception as e:
        logger.warning(f"Reddit search error r/{subreddit}: {e}")
        return []


def discover(
    queries: list[str],
    niche: str = "",
    extra_subreddits: list[str] = None,
) -> list[dict]:
    """
    Search Reddit for resource posts matching queries.
    Extracts external URLs from post bodies.

    Returns list of {url, domain, url_hash, source_subreddit, reddit_query}.
    """
    subreddits = list(BASE_SUBREDDITS)
    if extra_subreddits:
        subreddits.extend(extra_subreddits)
    # Add niche-specific subreddit if niche provided
    if niche:
        subreddits.append(niche.replace(" ", ""))  # e.g. "Legal" → r/Legal

    seen_hashes = set()
    results = []

    for query in queries:
        for sub in subreddits[:4]:  # cap at 4 subreddits per query to manage rate limits
            logger.info(f"  Reddit r/{sub}: {query[:40]}")
            posts = search_subreddit_json(sub, query)

            for post in posts:
                # Extract URLs from selftext
                selftext = post.get("selftext", "") or ""
                post_url = post.get("url", "") or ""

                urls_in_text = _extract_urls_from_text(selftext)
                # Also include the post URL if it's an external link
                if is_valid_url(post_url) and "reddit.com" not in post_url:
                    urls_in_text.append(post_url)

                for url in urls_in_text:
                    h = url_hash(url)
                    if h not in seen_hashes:
                        seen_hashes.add(h)
                        results.append({
                            "url":             url,
                            "domain":          extract_domain(url),
                            "url_hash":        h,
                            "source_subreddit": sub,
                            "reddit_query":    query,
                            "post_title":      post.get("title", "")[:100],
                        })

            sleep_rate("reddit")

    return results


if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")

    print("Testing Reddit source (public JSON, no auth)...")
    results = discover(
        queries=["write for us guest post seo"],
        niche="SEO",
    )
    print(f"  Got {len(results)} URLs from Reddit")
    if results:
        print(f"  Sample: {results[0]['url']}")
    print("Reddit source test complete")
