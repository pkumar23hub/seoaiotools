"""
discovery/sources/serp_api.py — SerpAPI Google search source.

Uses SerpAPI's free tier (100 searches/month) to run Google footprint
queries. Tracks monthly usage in the DB and refuses to exceed the budget.

Each call returns up to 10 organic results (SERP_RESULTS_PER_QUERY).
"""

import requests
from typing import Optional

from utils.logger import get_logger
from utils.helpers import is_valid_url, extract_domain, url_hash, sleep_rate
import config

logger = get_logger(__name__)

SERP_API_ENDPOINT = "https://serpapi.com/search.json"


def search(
    query: str,
    num: int = None,
    db=None,
) -> list[dict]:
    """
    Run a single Google search via SerpAPI.

    Args:
        query: The search query string (footprint template, already injected).
        num:   Number of results (max 10 on free tier).
        db:    Optional Database instance for budget tracking.

    Returns:
        List of dicts: {url, title, snippet, domain, url_hash}
        Empty list if no API key, budget exceeded, or request fails.
    """
    if not config.SERPAPI_KEY:
        logger.warning("SerpAPI key not configured — skipping SERP query")
        return []

    if num is None:
        num = config.SERP_RESULTS_PER_QUERY

    # Budget check
    if db is not None:
        used = db.get_serp_usage()
        if used >= config.SERPAPI_MONTHLY_BUDGET:
            logger.warning(
                f"SerpAPI monthly budget reached ({used}/{config.SERPAPI_MONTHLY_BUDGET}). "
                "Falling back to CC-only mode."
            )
            return []

    params = {
        "q":       query,
        "api_key": config.SERPAPI_KEY,
        "num":     num,
        "hl":      "en",
        "gl":      "us",
    }

    try:
        resp = requests.get(SERP_API_ENDPOINT, params=params, timeout=15)
        resp.raise_for_status()
        data = resp.json()

        # Increment budget counter
        if db is not None:
            db.increment_serp_usage(1)

        organic = data.get("organic_results", [])
        results = []
        for item in organic:
            url = item.get("link", "")
            if not is_valid_url(url):
                continue
            results.append({
                "url":     url,
                "title":   item.get("title", ""),
                "snippet": item.get("snippet", ""),
                "domain":  extract_domain(url),
                "url_hash": url_hash(url),
            })

        logger.debug(f"SerpAPI: '{query[:60]}' → {len(results)} results")
        sleep_rate("serp_api")
        return results

    except requests.HTTPError as e:
        if e.response.status_code == 429:
            logger.warning("SerpAPI rate limit hit (429). Sleeping 60s...")
            import time; import time; time.sleep(60)
        else:
            logger.error(f"SerpAPI HTTP error: {e}")
        return []
    except Exception as e:
        logger.error(f"SerpAPI error for query '{query[:50]}': {e}")
        return []


def batch_search(
    queries: list[str],
    db=None,
) -> list[dict]:
    """
    Run multiple queries, merge and deduplicate results.
    Stops if budget is exhausted mid-batch.
    """
    seen_hashes = set()
    all_results = []

    for q in queries:
        results = search(q, db=db)
        if not results and not config.SERPAPI_KEY:
            break  # No key — no point continuing
        for r in results:
            h = r.get("url_hash", "")
            if h and h not in seen_hashes:
                seen_hashes.add(h)
                all_results.append(r)

    return all_results


if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")

    if not config.SERPAPI_KEY:
        print("No SERPAPI_KEY in .env — skipping live test.")
        print("SerpAPI module structure OK")
    else:
        print("Testing SerpAPI source (live)...")
        results = search("personal injury lawyer blog write for us", num=5)
        print(f"  Got {len(results)} results")
        if results:
            print(f"  Sample: {results[0]['url']}")
        print("SerpAPI source test complete")
