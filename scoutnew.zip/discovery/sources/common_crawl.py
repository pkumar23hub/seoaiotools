"""
discovery/sources/common_crawl.py — Common Crawl CDX API source.

Queries the CC CDX index by URL pattern to discover pages at scale.
No API key required. Rate-limited to respect CC's servers.

CDX API format:
  GET https://index.commoncrawl.org/{INDEX}-index
      ?url={pattern}&output=json&filter=status:200&filter=mime:text/html&limit={n}

Patterns use * wildcard:
  *.example.com/* — all subdomains + paths
  *write-for-us*  — any URL containing the phrase
"""

import time
import json
import requests
from typing import Iterator
from urllib.parse import urlencode

from utils.logger import get_logger
from utils.helpers import is_valid_url, extract_domain, url_hash, sleep_rate
import config

logger = get_logger(__name__)

# Available CC indexes (most recent first). We query the top 2 for coverage.
CC_INDEXES = [
    "CC-MAIN-2025-13",
    "CC-MAIN-2024-51",
]
CDX_BASE = "https://index.commoncrawl.org/{index}-index"


def query_cdx(
    url_pattern: str,
    limit: int = None,
    index: str = None,
) -> list[dict]:
    """
    Query a single CDX index for a URL pattern.

    Returns list of dicts with keys: url, status, mime, timestamp, domain.
    Empty list on error or no results.
    """
    if limit is None:
        limit = config.CC_RESULTS_PER_PATTERN
    if index is None:
        index = config.CC_INDEX

    endpoint = CDX_BASE.format(index=index)
    params = {
        "url":    url_pattern,
        "output": "json",
        "filter": ["status:200", "mime:text/html"],
        "limit":  limit,
        "fl":     "url,status,mime,timestamp",
    }

    try:
        resp = requests.get(
            endpoint,
            params=params,
            timeout=20,
            headers={"User-Agent": "Scout/1.0 (link-research; contact@scout.local)"},
        )
        if resp.status_code == 503:
            logger.warning("CC CDX rate-limited (503). Sleeping 30s...")
            time.sleep(30)
            return []
        if resp.status_code != 200:
            logger.debug(f"CDX non-200: {resp.status_code} for {url_pattern}")
            return []

        results = []
        for line in resp.text.strip().splitlines():
            try:
                rec = json.loads(line)
                url = rec.get("url", "")
                if is_valid_url(url):
                    rec["domain"] = extract_domain(url)
                    rec["url_hash"] = url_hash(url)
                    results.append(rec)
            except json.JSONDecodeError:
                continue

        logger.debug(f"CDX [{index}] pattern={url_pattern!r} → {len(results)} results")
        return results

    except requests.RequestException as e:
        logger.warning(f"CDX request failed for {url_pattern!r}: {e}")
        return []


def query_cdx_multi_index(
    url_pattern: str,
    limit_per_index: int = None,
) -> list[dict]:
    """
    Query multiple CC indexes for a pattern and merge results.
    Deduplicates by url_hash.
    """
    if limit_per_index is None:
        limit_per_index = config.CC_RESULTS_PER_PATTERN

    seen_hashes = set()
    merged = []

    for index in CC_INDEXES:
        results = query_cdx(url_pattern, limit=limit_per_index, index=index)
        for r in results:
            h = r.get("url_hash", "")
            if h and h not in seen_hashes:
                seen_hashes.add(h)
                merged.append(r)
        sleep_rate("common_crawl")

    return merged


def discover_by_patterns(
    patterns: list[str],
    limit_per_pattern: int = None,
) -> list[dict]:
    """
    Run a list of URL patterns through CC CDX.
    Returns deduplicated results tagged with the pattern that found them.
    """
    if limit_per_pattern is None:
        limit_per_pattern = config.CC_RESULTS_PER_PATTERN

    seen_hashes = set()
    all_results = []

    for pattern in patterns:
        logger.info(f"  CDX query: {pattern}")
        results = query_cdx_multi_index(pattern, limit_per_index=limit_per_pattern)
        new = 0
        for r in results:
            h = r.get("url_hash", "")
            if h and h not in seen_hashes:
                seen_hashes.add(h)
                r["cc_pattern"] = pattern
                all_results.append(r)
                new += 1
        logger.debug(f"  → {new} new from {pattern!r}")

    return all_results


if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")

    print("Testing Common Crawl CDX source (live query)...")
    results = query_cdx("*/write-for-us*", limit=5)
    print(f"  Got {len(results)} results for */write-for-us*")
    if results:
        print(f"  Sample: {results[0]['url']}")

    results2 = query_cdx("*.blogspot.com/*", limit=5)
    print(f"  Got {len(results2)} results for *.blogspot.com/*")
    print("CDX source test complete")
