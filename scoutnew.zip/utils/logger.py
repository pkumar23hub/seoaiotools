"""
utils/logger.py — Centralised logging for Scout.

Every module calls: from utils.logger import get_logger
Then: logger = get_logger(__name__)

Logs go to:
  - Console: INFO and above, coloured via rich
  - File:    DEBUG and above, plain text, rotated daily
"""

import logging
import sys
from pathlib import Path
from logging.handlers import TimedRotatingFileHandler


def get_logger(name: str) -> logging.Logger:
    """
    Return a logger for the given module name.
    Safe to call multiple times — handlers are added only once.
    """
    logger = logging.getLogger(name)

    if logger.handlers:
        return logger  # already configured

    logger.setLevel(logging.DEBUG)

    # ── Console handler (INFO+) ───────────────────────────────────────────────
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(logging.INFO)
    console.setFormatter(_ConsoleFormatter())
    logger.addHandler(console)

    # ── File handler (DEBUG+) ─────────────────────────────────────────────────
    try:
        from config import LOG_DIR
    except ImportError:
        # fallback when run standalone
        LOG_DIR = Path(__file__).parent.parent / "logs"
        LOG_DIR.mkdir(parents=True, exist_ok=True)

    log_file = LOG_DIR / "scout.log"
    file_handler = TimedRotatingFileHandler(
        log_file, when="midnight", backupCount=7, encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    ))
    logger.addHandler(file_handler)

    # Prevent propagation to root logger (avoids duplicate console output)
    logger.propagate = False

    return logger


class _ConsoleFormatter(logging.Formatter):
    """Coloured console output using ANSI codes."""

    COLOURS = {
        logging.DEBUG:    "\033[90m",   # dark grey
        logging.INFO:     "\033[0m",    # default
        logging.WARNING:  "\033[33m",   # yellow
        logging.ERROR:    "\033[31m",   # red
        logging.CRITICAL: "\033[1;31m", # bold red
    }
    RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:
        colour = self.COLOURS.get(record.levelno, self.RESET)
        prefix = f"[{record.levelname[0]}]"  # [D], [I], [W], [E], [C]
        msg = super().format(record)
        return f"{colour}{prefix} {msg}{self.RESET}"

    def __init__(self):
        super().__init__(
            fmt="%(message)s",
            datefmt="%H:%M:%S",
        )


if __name__ == "__main__":
    log = get_logger("test")
    log.debug("debug message")
    log.info("info message")
    log.warning("warning message")
    log.error("error message")
    print("Logger OK — check logs/scout.log for file output")
