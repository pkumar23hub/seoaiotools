"""
utils/helpers.py — Pure utility functions used across all Scout modules.

No external dependencies beyond stdlib. Safe to import anywhere.
"""

import hashlib
import re
import time
import unicodedata
from urllib.parse import urlparse, urlunparse, urlencode, quote
from typing import Optional


# ── URL Utilities ─────────────────────────────────────────────────────────────

def normalize_url(url: str) -> str:
    """
    Normalise a URL for consistent deduplication:
    - lowercase scheme + host
    - strip trailing slash
    - remove common tracking params (utm_*, fbclid, etc.)
    - strip fragment (#...)
    """
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    parsed = urlparse(url)
    scheme = "https"                          # always normalise to https
    host   = parsed.netloc.lower()
    host   = re.sub(r"^www\.", "", host)      # strip www.
    host   = host.split(":")[0]               # strip port
    path   = parsed.path.rstrip("/") or "/"
    # strip tracking query params
    query  = _strip_tracking_params(parsed.query)
    # drop fragment
    return urlunparse((scheme, host, path, "", query, ""))


def _strip_tracking_params(query: str) -> str:
    """Remove utm_*, fbclid, gclid, mc_* tracking parameters."""
    if not query:
        return ""
    tracking = re.compile(
        r"^(utm_|fbclid|gclid|mc_|ref=|source=|campaign=)", re.IGNORECASE
    )
    kept = [p for p in query.split("&") if not tracking.match(p)]
    return "&".join(kept)


def extract_domain(url: str) -> str:
    """Return bare domain (no scheme, no www, no path)."""
    try:
        parsed = urlparse(url if "://" in url else "https://" + url)
        host = parsed.netloc.lower()
        # strip www. and port
        host = re.sub(r"^www\.", "", host)
        host = host.split(":")[0]
        return host
    except Exception:
        return url.lower()


def url_hash(url: str) -> str:
    """MD5 hash of normalised URL — used as unique key in DB."""
    return hashlib.md5(normalize_url(url).encode()).hexdigest()


def domain_hash(url: str) -> str:
    """MD5 hash of domain — used for same-domain dedup flag."""
    return hashlib.md5(extract_domain(url).encode()).hexdigest()


def is_valid_url(url: str) -> bool:
    """Basic URL validity check — must have scheme + netloc."""
    try:
        p = urlparse(url)
        return p.scheme in ("http", "https") and bool(p.netloc)
    except Exception:
        return False


# ── Text Utilities ────────────────────────────────────────────────────────────

def slugify(text: str) -> str:
    """
    Convert text to a safe filename/DB slug.
    "Acme Legal Services" → "acme_legal_services"
    """
    text = unicodedata.normalize("NFKD", text)
    text = text.encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"[^\w\s-]", "", text).strip().lower()
    return re.sub(r"[\s-]+", "_", text)


def clean_text(text: str) -> str:
    """Strip HTML tags and extra whitespace from a string."""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def truncate(text: str, max_len: int = 200) -> str:
    """Truncate text to max_len characters, appending '...' if cut."""
    if not text:
        return ""
    return text[:max_len] + ("..." if len(text) > max_len else "")


# ── Keyword Utilities ─────────────────────────────────────────────────────────

def build_keyword_set(
    primary: str,
    secondary: list[str],
    niche: str,
    location: str,
) -> list[str]:
    """
    Expand user inputs into a deduplicated keyword set for use in
    footprint templates and relevance scoring.
    """
    kws = [primary] + [k for k in secondary if k]
    if niche and niche.lower() not in primary.lower():
        kws.append(niche)
    if location:
        kws.append(location)
        # Also add "primary + location" compound
        kws.append(f"{primary} {location}")
    # Deduplicate preserving order
    seen, result = set(), []
    for kw in kws:
        kw = kw.strip()
        if kw and kw.lower() not in seen:
            seen.add(kw.lower())
            result.append(kw)
    return result


def keyword_in_text(keyword: str, text: str) -> bool:
    """Case-insensitive whole-word keyword presence check."""
    pattern = re.compile(re.escape(keyword), re.IGNORECASE)
    return bool(pattern.search(text))


def count_keyword_hits(keywords: list[str], text: str) -> int:
    """Count how many distinct keywords appear in text."""
    return sum(1 for kw in keywords if keyword_in_text(kw, text))


# ── Rate Limiting ─────────────────────────────────────────────────────────────

def sleep_rate(source: str) -> None:
    """
    Sleep according to configured rate limit for a given source.
    Import config here to avoid circular imports.
    """
    try:
        from config import RATE_LIMITS
        delay = RATE_LIMITS.get(source, 1.0)
    except ImportError:
        delay = 1.0
    time.sleep(delay)


# ── Misc ──────────────────────────────────────────────────────────────────────

def chunk_list(lst: list, size: int) -> list[list]:
    """Split a list into chunks of given size."""
    return [lst[i:i + size] for i in range(0, len(lst), size)]


def safe_get(d: dict, *keys, default=None):
    """Safely traverse nested dict: safe_get(d, 'a', 'b', 'c')."""
    for k in keys:
        if not isinstance(d, dict):
            return default
        d = d.get(k, default)
    return d


if __name__ == "__main__":
    # Quick self-tests
    assert extract_domain("https://www.Example.com/path?x=1") == "example.com"
    assert extract_domain("http://sub.example.co.uk") == "sub.example.co.uk"
    u = normalize_url("HTTP://WWW.Example.com/page/?utm_source=google&q=1")
    assert "utm_source" not in u
    assert url_hash("https://example.com") == url_hash("http://www.example.com")
    assert slugify("Acme Legal Services!") == "acme_legal_services"
    kws = build_keyword_set("personal injury lawyer", ["car accident"], "Legal", "Houston TX")
    assert "Houston TX" in kws
    assert count_keyword_hits(["lawyer", "injury"], "Best injury lawyer in town") == 2
    print("All helper tests passed")
