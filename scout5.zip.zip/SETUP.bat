@echo off
setlocal enabledelayedexpansion

:: ============================================================
:: SCOUT - Zero-Cost Link Opportunity Pipeline
:: Installer v1.0.3 - fixed: venv path must have no spaces
:: ============================================================
:: Usage:
::   SETUP.bat                  - install to C:\scout (default)
::   SETUP.bat --skip-keys      - skip API key prompts
::   SETUP.bat --repair         - delete venv and reinstall
::   SETUP.bat --debug          - verbose pip output
::   SETUP.bat --help           - show this help
:: ============================================================

:: --- Parse flags ---
set "FLAG_SKIP_KEYS=0"
set "FLAG_REPAIR=0"
set "FLAG_DEBUG=0"
set "FLAG_HELP=0"

:parse_args
if "%~1"=="" goto args_done
if /i "%~1"=="--skip-keys" set "FLAG_SKIP_KEYS=1"
if /i "%~1"=="--repair"    set "FLAG_REPAIR=1"
if /i "%~1"=="--debug"     set "FLAG_DEBUG=1"
if /i "%~1"=="--help"      set "FLAG_HELP=1"
shift
goto parse_args
:args_done

if "%FLAG_HELP%"=="1" (
    echo.
    echo Scout Installer v1.0.3
    echo ======================
    echo Usage:
    echo   SETUP.bat                  - full install to C:\scout
    echo   SETUP.bat --skip-keys      - skip API key prompts
    echo   SETUP.bat --repair         - rebuild virtual environment
    echo   SETUP.bat --debug          - verbose pip output
    echo   SETUP.bat --help           - show this help
    echo.
    pause
    goto :eof
)

:: ============================================================
:: CRITICAL: Install to a path with NO SPACES
:: python -m venv silently hangs on paths containing spaces
:: ============================================================
set "INSTALL_DIR=C:\scout"
set "SOURCE_DIR=%~dp0"
if "%SOURCE_DIR:~-1%"=="\" set "SOURCE_DIR=%SOURCE_DIR:~0,-1%"

set "VENV_DIR=%INSTALL_DIR%\venv"
set "VENV_PYTHON=%VENV_DIR%\Scripts\python.exe"
set "VENV_PIP=%VENV_DIR%\Scripts\pip.exe"
set "LOG_FILE=%INSTALL_DIR%\setup_log.txt"
set "ENV_FILE=%INSTALL_DIR%\.env"
set "ERROR_COUNT=0"

echo.
echo ============================================================
echo   Scout - Zero-Cost Link Opportunity Pipeline
echo   Installer v1.0.3
echo ============================================================
echo.
echo   Install location : %INSTALL_DIR%
echo   Source files from: %SOURCE_DIR%
echo.
echo   NOTE: Installing to C:\scout to avoid venv path issues.
echo   Scout will run from C:\scout after install.
echo.

:: Create install dir and log
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
echo. > "%LOG_FILE%"
call :log "Scout Installer v1.0.3 started: %DATE% %TIME%"
call :log "Install dir: %INSTALL_DIR%"
call :log "Source dir: %SOURCE_DIR%"

:: ============================================================
:: STEP 1 - Find Python
:: ============================================================
echo [Step 1/8] Checking Python...
call :log "--- Step 1: Python ---"

set "PY_CMD="
for %%C in (python python3 py) do (
    if "!PY_CMD!"=="" (
        %%C --version >nul 2>&1
        if !errorlevel!==0 set "PY_CMD=%%C"
    )
)

if "%PY_CMD%"=="" (
    echo  [ERROR] Python not found. Install from https://python.org/downloads
    echo  Check "Add Python to PATH" during install.
    call :log "ERROR: Python not found"
    set /a ERROR_COUNT+=1
    goto :install_failed
)

for /f "tokens=2" %%V in ('%PY_CMD% --version 2^>^&1') do set "PY_VER=%%V"
for /f "tokens=1,2 delims=." %%A in ("%PY_VER%") do (
    set "PY_MAJOR=%%A"
    set "PY_MINOR=%%B"
)

if %PY_MAJOR% LSS 3 goto :py_old
if %PY_MAJOR%==3 if %PY_MINOR% LSS 9 goto :py_old
goto :py_ok

:py_old
echo  [ERROR] Python %PY_VER% too old. Need 3.9+. Get it at https://python.org/downloads
call :log "ERROR: Python too old: %PY_VER%"
set /a ERROR_COUNT+=1
goto :install_failed

:py_ok
echo  [OK] Python %PY_VER% (%PY_CMD%)
call :log "Python OK: %PY_VER%"

:: ============================================================
:: STEP 2 - Check pip
:: ============================================================
echo.
echo [Step 2/8] Checking pip...
call :log "--- Step 2: pip ---"

%PY_CMD% -m pip --version >nul 2>&1
if errorlevel 1 (
    echo  pip not found - bootstrapping via ensurepip...
    %PY_CMD% -m ensurepip --upgrade >> "%LOG_FILE%" 2>&1
    if errorlevel 1 (
        echo  [ERROR] Could not install pip. See %LOG_FILE%
        call :log "ERROR: ensurepip failed"
        set /a ERROR_COUNT+=1
        goto :install_failed
    )
)
echo  [OK] pip available
call :log "pip OK"

:: ============================================================
:: STEP 3 - Copy Scout files to install dir
:: ============================================================
echo.
echo [Step 3/8] Copying Scout files to %INSTALL_DIR%...
call :log "--- Step 3: copy files ---"

:: Only copy if source != install dir
if /i not "%SOURCE_DIR%"=="%INSTALL_DIR%" (
    xcopy "%SOURCE_DIR%\*" "%INSTALL_DIR%\" /E /I /Y /EXCLUDE:"%SOURCE_DIR%\xcopy_exclude.txt" >> "%LOG_FILE%" 2>&1
    :: xcopy_exclude not required - ignore error
    echo  [OK] Files copied
    call :log "Files copied from %SOURCE_DIR%"
) else (
    echo  [OK] Already in install directory - no copy needed
    call :log "Source = install dir, no copy"
)

:: ============================================================
:: STEP 4 - Create directories
:: ============================================================
echo.
echo [Step 4/8] Creating Scout directories...
call :log "--- Step 4: directories ---"

for %%D in (databases exports logs) do (
    if not exist "%INSTALL_DIR%\%%D" (
        mkdir "%INSTALL_DIR%\%%D"
        echo  Created: %%D\
    ) else (
        echo  [OK] %%D\ exists
    )
)
call :log "Directories OK"

:: ============================================================
:: STEP 5 - Virtual environment (NO SPACES in path - critical)
:: ============================================================
echo.
echo [Step 5/8] Creating virtual environment...
call :log "--- Step 5: venv ---"

if "%FLAG_REPAIR%"=="1" (
    if exist "%VENV_DIR%" (
        echo  --repair: removing existing venv...
        rmdir /s /q "%VENV_DIR%"
        call :log "Repair: removed old venv"
    )
)

:: Detect and remove partial/broken venv
if exist "%VENV_DIR%" (
    if not exist "%VENV_PYTHON%" (
        echo  Partial venv detected - removing and rebuilding...
        call :log "Partial venv detected, removing"
        rmdir /s /q "%VENV_DIR%"
    )
)

if not exist "%VENV_DIR%" (
    echo  Creating venv at %VENV_DIR%...
    echo  (using --without-pip to prevent hang^)
    call :log "Running: %PY_CMD% -m venv --without-pip %VENV_DIR%"
    %PY_CMD% -m venv --without-pip "%VENV_DIR%"
    if errorlevel 1 (
        echo  [ERROR] venv creation failed. See %LOG_FILE%
        echo  Try running as Administrator.
        call :log "ERROR: venv failed"
        set /a ERROR_COUNT+=1
        goto :install_failed
    )
    echo  [OK] venv created - bootstrapping pip...
    call :log "venv skeleton created, bootstrapping pip"
    "%VENV_PYTHON%" -m ensurepip --upgrade >> "%LOG_FILE%" 2>&1
    if errorlevel 1 (
        call :log "ensurepip failed, trying pip upgrade directly"
        "%VENV_PYTHON%" -m pip install --upgrade pip >> "%LOG_FILE%" 2>&1
    )
    echo  [OK] pip bootstrapped
) else (
    echo  [OK] venv already exists
)

call :log "venv OK"

:: ============================================================
:: STEP 6 - Install dependencies
:: ============================================================
echo.
echo [Step 6/8] Installing dependencies...
echo  (This takes 2-5 minutes - you will see live output below)
echo  -------------------------------------------------------
call :log "--- Step 6: pip install ---"

if not exist "%INSTALL_DIR%\requirements.txt" (
    echo  [ERROR] requirements.txt not found in %INSTALL_DIR%
    call :log "ERROR: requirements.txt missing"
    set /a ERROR_COUNT+=1
    goto :install_failed
)

if "%FLAG_DEBUG%"=="1" (
    "%VENV_PIP%" install -v -r "%INSTALL_DIR%\requirements.txt"
) else (
    "%VENV_PIP%" install -r "%INSTALL_DIR%\requirements.txt"
    if errorlevel 1 (
        echo  -------------------------------------------------------
        echo  Retrying with --no-cache-dir...
        call :log "pip failed, retrying --no-cache-dir"
        "%VENV_PIP%" install --no-cache-dir -r "%INSTALL_DIR%\requirements.txt"
    )
)
echo  -------------------------------------------------------

if errorlevel 1 (
    echo  [ERROR] pip install failed. See %LOG_FILE%
    echo  Run: SETUP.bat --repair --debug  for verbose output.
    call :log "ERROR: pip install failed"
    set /a ERROR_COUNT+=1
    goto :install_failed
)

echo  [OK] All packages installed
call :log "pip install OK"

:: Quick import check
"%VENV_PYTHON%" -c "import click, rich, httpx, praw, openpyxl, pandas, bs4, dotenv" >> "%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo  [WARNING] Package import check failed - some features may not work
    call :log "WARNING: package import check failed"
) else (
    echo  [OK] Package imports verified
    call :log "Package imports OK"
)

:: ============================================================
:: STEP 7 - API Keys
:: ============================================================
echo.
echo [Step 7/8] API Key Configuration...
call :log "--- Step 7: API keys ---"

if "%FLAG_SKIP_KEYS%"=="1" (
    echo  --skip-keys: skipping. Run SETUP.bat again to configure keys.
    call :log "Skipping API keys"
    goto :keys_done
)

if exist "%ENV_FILE%" (
    echo.
    set /p "OVERWRITE_ENV=  .env already exists. Overwrite with new keys? [y/N]: "
    if /i not "!OVERWRITE_ENV!"=="y" (
        echo  Keeping existing .env
        call :log "Keeping existing .env"
        goto :keys_done
    )
)

echo.
echo  ============================================================
echo   API Key Setup - all keys are FREE, press Enter to skip any
echo  ============================================================
echo.
echo  [1/4] SerpAPI - 100 free searches/month
echo        https://serpapi.com/users/sign_up  ^> Dashboard ^> API Key
echo.
set /p "KEY_SERP=  SerpAPI key (Enter to skip): "
echo.
echo  [2/4] Open PageRank - 10,000 free/hour permanently
echo        https://www.domcop.com/openpagerank/  ^> Dashboard ^> API Key
echo.
set /p "KEY_OPR=  OPR key (Enter to skip): "
echo.
echo  [3/4] Reddit API - free
echo        reddit.com/prefs/apps ^> create app ^> script type
echo        client_id = text under app name
echo.
set /p "KEY_REDDIT_ID=  Reddit client_id (Enter to skip): "
set /p "KEY_REDDIT_SECRET=  Reddit client_secret (Enter to skip): "
set /p "KEY_REDDIT_USER=  Your Reddit username: "
if "!KEY_REDDIT_USER!"=="" set "KEY_REDDIT_USER=YOUR_USERNAME"
echo.
echo  [4/4] GitHub Token - free
echo        github.com/settings/tokens ^> classic token ^> public_repo scope
echo.
set /p "KEY_GITHUB=  GitHub token (Enter to skip): "
echo.

(
    echo # Scout API Keys
    echo SERPAPI_KEY=!KEY_SERP!
    echo OPR_KEY=!KEY_OPR!
    echo REDDIT_CLIENT_ID=!KEY_REDDIT_ID!
    echo REDDIT_CLIENT_SECRET=!KEY_REDDIT_SECRET!
    echo REDDIT_USER_AGENT=scout:v1.0 (by /u/!KEY_REDDIT_USER!)
    echo GITHUB_TOKEN=!KEY_GITHUB!
) > "%ENV_FILE%"

echo  [OK] .env written to %ENV_FILE%
call :log ".env written"

:keys_done
if not exist "%ENV_FILE%" (
    if exist "%INSTALL_DIR%\.env.example" (
        copy "%INSTALL_DIR%\.env.example" "%ENV_FILE%" >nul
        call :log ".env created from example"
    )
)

:: ============================================================
:: STEP 8 - Verification
:: ============================================================
echo.
echo [Step 8/8] Running verification tests...
call :log "--- Step 8: verification ---"

if exist "%INSTALL_DIR%\_verify.py" (
    "%VENV_PYTHON%" "%INSTALL_DIR%\_verify.py"
    if errorlevel 1 (
        echo  [WARNING] Some tests failed - check output above
        call :log "WARNING: verification had failures"
    ) else (
        call :log "Verification passed"
    )
) else (
    echo  [WARNING] _verify.py not found - skipping
    call :log "WARNING: _verify.py missing"
)

:: ============================================================
:: Generate launchers
:: ============================================================
call :log "Generating launchers"

(
    echo @echo off
    echo cd /d "%INSTALL_DIR%"
    echo call "%VENV_DIR%\Scripts\activate.bat"
    echo python main.py %%*
) > "%INSTALL_DIR%\scout.bat"

(
    echo @echo off
    echo echo Repairing Scout...
    echo call "%INSTALL_DIR%\SETUP.bat" --repair
) > "%INSTALL_DIR%\repair.bat"

call :log "Launchers generated"

:: ============================================================
:: Done
:: ============================================================
echo.
echo ============================================================
echo   Installation Complete
echo ============================================================
echo.
echo   Scout installed to: %INSTALL_DIR%
echo.
echo   To run Scout:
echo     Open CMD and run: C:\scout\scout.bat discover
echo     Or: cd C:\scout  then  venv\Scripts\activate  then  python main.py discover
echo.
echo   Commands:
echo     scout.bat discover    - find link opportunities
echo     scout.bat assess      - score results
echo     scout.bat export      - export to Excel/CSV
echo     scout.bat status      - check API keys
echo     scout.bat --help      - all commands
echo.
if %ERROR_COUNT% GTR 0 (
    echo   Completed with %ERROR_COUNT% warning(s). See: %LOG_FILE%
)
echo   Full log: %LOG_FILE%
echo.
echo Press any key to close...
pause >nul
goto :eof

:: ============================================================
:install_failed
:: ============================================================
echo.
echo ============================================================
echo   Installation Failed
echo ============================================================
echo.
echo   Errors: %ERROR_COUNT%
echo   Log: %LOG_FILE%
echo.
echo   Common fixes:
echo     Python missing    - install from python.org (check Add to PATH)
echo     venv hangs        - already handled, path is now C:\scout
echo     pip fails         - check internet, run SETUP.bat --debug
echo     Access denied     - right-click SETUP.bat and Run as Administrator
echo.
echo Press any key to close...
pause >nul
exit /b 1

:: ============================================================
:log
:: ============================================================
echo [%TIME%] %~1 >> "%LOG_FILE%"
goto :eof
